-- Run this whole file once in Supabase: Project > SQL Editor > New query > paste > Run.

create table if not exists calls (
  id text primary key,
  user_id uuid not null,
  number text not null,
  started_at bigint not null,
  duration_seconds int not null default 0,
  recording_path text,
  status text not null default 'recorded', -- recorded -> processing -> done | failed
  transcript text,
  summary text,
  urgent boolean,
  extracted text, -- JSON string: names/dates/phone numbers/suggested callback
  created_at timestamptz not null default now()
);
create index if not exists calls_user_started on calls(user_id, started_at desc);

alter table calls enable row level security;

-- The app (anon key + a signed-in user) can only see and insert its own rows.
create policy "calls_select_own" on calls for select to authenticated
  using (auth.uid() = user_id);
create policy "calls_insert_own" on calls for insert to authenticated
  with check (auth.uid() = user_id);

-- The Edge Function updates transcript/summary/status using the SERVICE ROLE key, which
-- bypasses RLS entirely -- so no update policy is needed (or wanted) for the app's anon key.
