-- Run this whole file once in Supabase: Project > SQL Editor > New query > paste > Run.

create table if not exists calls (
  id text primary key,
  user_id uuid not null,
  number text not null,
  started_at bigint not null,
  duration_seconds int not null default 0,
  recording_path text,
  status text not null default 'recorded', -- recorded -> processing -> done | failed
  transcript text,
  summary text,
  urgent boolean,
  extracted text, -- JSON string: names/dates/phone numbers/suggested callback
  created_at timestamptz not null default now()
);
create index if not exists calls_user_started on calls(user_id, started_at desc);

alter table calls enable row level security;

-- The app (anon key + a signed-in user) can only see and insert its own rows.
create policy "calls_select_own" on calls for select to authenticated
  using (auth.uid() = user_id);
create policy "calls_insert_own" on calls for insert to authenticated
  with check (auth.uid() = user_id);

-- The Edge Function updates transcript/summary/status using the SERVICE ROLE key, which
-- bypasses RLS entirely -- so no update policy is needed (or wanted) for the app's anon key.

-- ============================================================
-- V2: priority rules, privacy rules, availability, conversations
-- ============================================================

-- Who gets AI-answered vs rings through normally vs gets silently declined.
create table if not exists contacts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  number text not null,
  name text not null default '',
  priority text not null default 'normal' check (priority in ('vip', 'normal', 'blocked')),
  created_at timestamptz not null default now()
);
create index if not exists contacts_user_number on contacts(user_id, number);
alter table contacts enable row level security;
create policy "contacts_rw_own" on contacts for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Confidential phrases the AI must never say out loud. Checked by a DETERMINISTIC filter in
-- the Edge Function, not just a prompt instruction -- see README for why that distinction matters.
create table if not exists privacy_rules (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  phrase text not null,
  created_at timestamptz not null default now()
);
alter table privacy_rules enable row level security;
create policy "privacy_rules_rw_own" on privacy_rules for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- One row per user: current availability, feeds the AI's reply content.
create table if not exists settings (
  user_id uuid primary key,
  status text not null default 'available' check (status in ('available', 'busy', 'in_meeting', 'custom')),
  custom_message text not null default '',
  callback_window text not null default 'later today',
  auto_answer_enabled boolean not null default true,
  ring_delay_seconds int not null default 8,
  updated_at timestamptz not null default now()
);
alter table settings enable row level security;
create policy "settings_rw_own" on settings for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Extend calls for direction, priority tier at call time, and the turn-by-turn conversation.
alter table calls add column if not exists direction text not null default 'incoming' check (direction in ('incoming', 'outgoing'));
alter table calls add column if not exists priority text;
alter table calls add column if not exists turns text; -- JSON array: [{speaker, text, ts}, ...]

-- V3: Zara persona (configurable name, defaults match the requested script).
alter table settings add column if not exists assistant_name text not null default 'Zara';
alter table settings add column if not exists owner_name text not null default 'Shivay';
