# AI Voicemail (V1 — foundation)

An Android app that can answer an incoming call for you, greet the caller, record the
conversation, and afterward automatically transcribe it and generate a summary — viewable in an
in-app dashboard. Built on Supabase (storage + database + a server-side function) and OpenAI
(Whisper for transcription, GPT for summarizing).

## What V1 actually does, precisely

1. A call rings. You get a notification with a **"Let AI Answer"** action.
2. You tap it. The app answers the call, switches to speakerphone, and plays a short spoken
   greeting (Android's built-in text-to-speech — robotic-sounding, not OpenAI's voice; see
   "What's deliberately not in V1" below).
3. Everything after that is recorded — the mic picks up both the greeting and whatever the
   caller says, acoustically (see the audio-quality note below for why).
4. When the call ends, the app tries to hang up automatically (best-effort — see note below),
   uploads the recording to Supabase, and asks a server-side function to transcribe + summarize
   it.
5. The dashboard shows each call: number, time, duration, and — once processing finishes —
   summary, full transcript, extracted names/dates/phone numbers, a suggested callback, and an
   "urgent" flag, plus a button to play the actual recording.

## What's deliberately not in V1

- **No live back-and-forth conversation.** The AI doesn't respond to what the caller says during
  the call — it plays one greeting, then just records. You chose this scope on purpose, since
  live conversation (real-time speech-to-text, an LLM reply, and speech synthesis, all within a
  live call) is a much harder, more experimental phase to build on top of this once the
  foundation is proven to work.
- **No OpenAI voice for the greeting.** Using OpenAI's TTS live, mid-call, means a network
  round-trip right when timing matters most — real risk of silence or a cut-off greeting if it's
  slow. V1 uses Android's own offline TTS for reliability. Swapping in OpenAI's voice for the
  greeting (pre-generating and caching it, since the greeting text doesn't change) is a
  reasonable next step once this foundation is confirmed working.

## Known limitations — please read before relying on this

- **Audio quality.** This isn't a clean call-audio feed — a third-party app can't get one
  without being the phone's default Dialer (a much bigger undertaking). What actually happens:
  the call goes on speakerphone, and the microphone picks up the room's audio, including the
  AI's own greeting played out loud. Expect some echo/crosstalk in the recording and transcript,
  more noticeable in a noisy room.
- **Auto hang-up is best-effort.** `TelecomManager.endCall()` isn't guaranteed to work for an
  app that isn't the default Dialer, and this varies by Android version/OEM. If it doesn't work
  on your phone, the call just stays connected until you end it manually from the normal call
  screen — it won't hang forever unattended, but you may need to glance at the phone.
- **Recording itself may not work at all on some devices**, same Android 10+ restriction covered
  in the earlier call-recording feature of the other project — no reliable non-root fix exists.
- **Legal/consent.** Having an AI answer, converse with (even just greet), and record someone who
  doesn't know they're talking to an automated system touches real consent and disclosure rules
  that vary by location — this is worth checking for wherever you and your callers are. The
  greeting includes a spoken disclosure ("you've reached an AI assistant") specifically so callers
  aren't misled, but that doesn't substitute for knowing your local rules.
- **Nothing here has been compiled or run** — I have no internet access or device in my
  environment, so GitHub Actions building it successfully is the real first test, same as every
  project before this one. If the build fails, send me the Actions log the same way as always.

## 1. Create the Supabase project

1. https://supabase.com → new project (free tier). Note the **Project URL** and **anon key**
   (Project Settings > API) for `Config.kt` later, and the **Project Reference** (the short ID in
   your project's URL) for the GitHub Actions variable later.
2. **SQL Editor** → paste and run `supabase.sql` (creates the `calls` table + security policies).
3. Follow `storage_setup.md` to create the `call_recordings` bucket.
4. **Authentication > Providers** → enable **Email**, and in **Authentication > Email Templates >
   Magic Link**, make sure the body includes `{{ .Token }}` (same reasoning as the earlier
   project: without it you get a clickable link instead of a 6-digit code).

## 2. Set your OpenAI API key — **only in Supabase, never in the app or GitHub**

1. Get an API key from https://platform.openai.com (requires billing set up on your OpenAI
   account — Whisper and GPT calls cost a small amount per call processed).
2. In Supabase: **Edge Functions > Manage secrets** (or **Project Settings > Edge Functions**),
   add a secret named `OPENAI_API_KEY` with your key as the value.

This key never appears in the Android app's code and never needs to go into a GitHub secret —
it lives only inside Supabase, where the Edge Function reads it server-side.

## 3. Fill in Config.kt

Edit `app/src/main/java/com/example/aivoicemail/Config.kt` with your Supabase Project URL and
anon key (same two values as step 1).

## 4. Push to GitHub

1. New repo (private is fine), no README.
2. Upload this entire `AIVoicemail.zip` as-is (don't extract it) to the repo root, plus
   `.github/workflows/build.yml` at that exact path (type the full path into the filename box
   when uploading a single file, GitHub creates the folders).
3. Commit to `main`.

## 5. (Optional but recommended) Let Actions deploy the Edge Function too

Without this step, you'd need to deploy `supabase/functions/process-call` yourself via the
Supabase CLI from a computer — skip that entirely by letting GitHub Actions do it:

1. In Supabase: **Account > Access Tokens**, generate a new token.
2. In your GitHub repo: **Settings > Secrets and variables > Actions**:
   - Add a **secret** named `SUPABASE_ACCESS_TOKEN` with that token.
   - Add a **variable** (not a secret — this one's not sensitive) named `SUPABASE_PROJECT_REF`
     with your project's reference ID from step 1.
3. Push again (or re-run the workflow). The `deploy-function` job will now run alongside the APK
   build and publish `process-call` to your Supabase project automatically on every push.

If you skip this, the APK still builds fine — you'd just need to deploy the function manually
later, from somewhere with the Supabase CLI available.

## 6. Install and set up

1. Download the APK from the Actions run's Artifacts, install on your phone.
2. Open the app, grant permissions, sign in with email (OTP code), and set battery usage to
   Unrestricted — plus your phone's own autostart/background-app manager if it's a Vivo/OPPO/
   Xiaomi-style phone, same reasoning as the dual-phone project: Android's battery setting alone
   often isn't enough to keep a background receiver reliably alive.

## Testing it

Call the phone from another number. You should see the "Let AI Answer" notification while it's
ringing. Tap it, listen for the greeting (on speaker), say something, then hang up from either
end. Check the Diagnostics section in the app for what happened at each step, and check the Call
history section a short while after — it'll show "processing" until the Edge Function finishes,
then "done" with the summary and transcript filled in.
