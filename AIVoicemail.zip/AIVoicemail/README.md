# AI Voicemail (V1 — foundation)

An Android app that can answer an incoming call for you, greet the caller, record the
conversation, and afterward automatically transcribe it and generate a summary — viewable in an
in-app dashboard. Built on Supabase (storage + database + a server-side function) and OpenAI
(Whisper for transcription, GPT for summarizing).

## What V1 actually does, precisely

1. A call rings. You get a notification with a **"Let AI Answer"** action.
2. You tap it. The app answers the call, switches to speakerphone, and plays a short spoken
   greeting (Android's built-in text-to-speech — robotic-sounding, not OpenAI's voice; see
   "What's deliberately not in V1" below).
3. Everything after that is recorded — the mic picks up both the greeting and whatever the
   caller says, acoustically (see the audio-quality note below for why).
4. When the call ends, the app tries to hang up automatically (best-effort — see note below),
   uploads the recording to Supabase, and asks a server-side function to transcribe + summarize
   it.
5. The dashboard shows each call: number, time, duration, and — once processing finishes —
   summary, full transcript, extracted names/dates/phone numbers, a suggested callback, and an
   "urgent" flag, plus a button to play the actual recording.

## What's deliberately not in V1

- **No live back-and-forth conversation.** The AI doesn't respond to what the caller says during
  the call — it plays one greeting, then just records. You chose this scope on purpose, since
  live conversation (real-time speech-to-text, an LLM reply, and speech synthesis, all within a
  live call) is a much harder, more experimental phase to build on top of this once the
  foundation is proven to work.
- **No OpenAI voice for the greeting.** Using OpenAI's TTS live, mid-call, means a network
  round-trip right when timing matters most — real risk of silence or a cut-off greeting if it's
  slow. V1 uses Android's own offline TTS for reliability. Swapping in OpenAI's voice for the
  greeting (pre-generating and caching it, since the greeting text doesn't change) is a
  reasonable next step once this foundation is confirmed working.

## Known limitations — please read before relying on this

- **Audio quality.** This isn't a clean call-audio feed — a third-party app can't get one
  without being the phone's default Dialer (a much bigger undertaking). What actually happens:
  the call goes on speakerphone, and the microphone picks up the room's audio, including the
  AI's own greeting played out loud. Expect some echo/crosstalk in the recording and transcript,
  more noticeable in a noisy room.
- **Auto hang-up is best-effort.** `TelecomManager.endCall()` isn't guaranteed to work for an
  app that isn't the default Dialer, and this varies by Android version/OEM. If it doesn't work
  on your phone, the call just stays connected until you end it manually from the normal call
  screen — it won't hang forever unattended, but you may need to glance at the phone.
- **Recording itself may not work at all on some devices**, same Android 10+ restriction covered
  in the earlier call-recording feature of the other project — no reliable non-root fix exists.
- **Legal/consent.** Having an AI answer, converse with (even just greet), and record someone who
  doesn't know they're talking to an automated system touches real consent and disclosure rules
  that vary by location — this is worth checking for wherever you and your callers are. The
  greeting includes a spoken disclosure ("you've reached an AI assistant") specifically so callers
  aren't misled, but that doesn't substitute for knowing your local rules.
- **Nothing here has been compiled or run** — I have no internet access or device in my
  environment, so GitHub Actions building it successfully is the real first test, same as every
  project before this one. If the build fails, send me the Actions log the same way as always.

## 1. Create the Supabase project

1. https://supabase.com → new project (free tier). Note the **Project URL** and **anon key**
   (Project Settings > API) for `Config.kt` later, and the **Project Reference** (the short ID in
   your project's URL) for the GitHub Actions variable later.
2. **SQL Editor** → paste and run `supabase.sql` (creates the `calls` table + security policies).
3. Follow `storage_setup.md` to create the `call_recordings` bucket.
4. **Authentication > Providers** → enable **Email**, and in **Authentication > Email Templates >
   Magic Link**, make sure the body includes `{{ .Token }}` (same reasoning as the earlier
   project: without it you get a clickable link instead of a 6-digit code).

## 2. Set your OpenAI API key — **only in Supabase, never in the app or GitHub**

1. Get an API key from https://platform.openai.com (requires billing set up on your OpenAI
   account — Whisper and GPT calls cost a small amount per call processed).
2. In Supabase: **Edge Functions > Manage secrets** (or **Project Settings > Edge Functions**),
   add a secret named `OPENAI_API_KEY` with your key as the value.

This key never appears in the Android app's code and never needs to go into a GitHub secret —
it lives only inside Supabase, where the Edge Function reads it server-side.

## 3. Fill in Config.kt

Edit `app/src/main/java/com/example/aivoicemail/Config.kt` with your Supabase Project URL and
anon key (same two values as step 1).

## 4. Push to GitHub

1. New repo (private is fine), no README.
2. Upload this entire `AIVoicemail.zip` as-is (don't extract it) to the repo root, plus
   `.github/workflows/build.yml` at that exact path (type the full path into the filename box
   when uploading a single file, GitHub creates the folders).
3. Commit to `main`.

## 5. (Optional but recommended) Let Actions deploy the Edge Function too

Without this step, you'd need to deploy `supabase/functions/process-call` yourself via the
Supabase CLI from a computer — skip that entirely by letting GitHub Actions do it:

1. In Supabase: **Account > Access Tokens**, generate a new token.
2. In your GitHub repo: **Settings > Secrets and variables > Actions**:
   - Add a **secret** named `SUPABASE_ACCESS_TOKEN` with that token.
   - Add a **variable** (not a secret — this one's not sensitive) named `SUPABASE_PROJECT_REF`
     with your project's reference ID from step 1.
3. Push again (or re-run the workflow). The `deploy-function` job will now run alongside the APK
   build and publish `process-call` to your Supabase project automatically on every push.

If you skip this, the APK still builds fine — you'd just need to deploy the function manually
later, from somewhere with the Supabase CLI available.

## 6. Install and set up

1. Download the APK from the Actions run's Artifacts, install on your phone.
2. Open the app, grant permissions, sign in with email (OTP code), and set battery usage to
   Unrestricted — plus your phone's own autostart/background-app manager if it's a Vivo/OPPO/
   Xiaomi-style phone, same reasoning as the dual-phone project: Android's battery setting alone
   often isn't enough to keep a background receiver reliably alive.

## Testing it

Call the phone from another number. You should see the "Let AI Answer" notification while it's
ringing. Tap it, listen for the greeting (on speaker), say something, then hang up from either
end. Check the Diagnostics section in the app for what happened at each step, and check the Call
history section a short while after — it'll show "processing" until the Edge Function finishes,
then "done" with the summary and transcript filled in.

---

# V2 — glass UI, priority routing, auto-answer, turn-based AI, privacy enforcement

This is a major rework of V1. Read this section before setting it up again.

## What changed

**UI**
- Hamburger navigation drawer: Incoming Calls, Outgoing Calls, Recorded Calls, Conversations,
  plus a Setup section (permissions, account, availability, contacts, privacy rules, diagnostics).
- A translucent "glass-style" card used throughout (soft transparency + rounded corners). Worth
  being honest about: this isn't full blur-behind glassmorphism -- that needs a background to
  blur, which isn't practical behind a scrolling list, and it's not something I can verify looks
  good without actually seeing it rendered. This gives the same visual language without that risk.
- Dark mode toggle (top bar), a consistent light/dark color scheme.
- A search bar on each call list (filters by number, summary, and transcript text).
- A small colored sync-status dot in the top bar (green = last AI step succeeded, red = error,
  gray = nothing has run yet).
- A new app icon (same one from V1, carried over).

**Auto-answer, with an override you can always use**
- Default behavior is now fully automatic: the phone rings, and after a configurable delay (set
  in Availability, default 8 seconds) the AI answers on its own -- no tap required.
- A notification still appears the moment it starts ringing, with **Answer now (AI)** and
  **Don't let AI answer** buttons, so you always have a window to take the call yourself or stop
  the AI from engaging, right up until the countdown fires.
- **Priority contacts** change this: numbers marked **VIP** always ring through normally, AI
  never touches them. Numbers marked **Blocked** also never get AI engagement (though this isn't
  a true silent network-level block -- see the caveat below).

**Real interaction, built to be reliable rather than fully open-ended**
- The AI now has an actual back-and-forth with the caller (up to 3 exchanges), not just a single
  greeting. Each turn: the caller speaks, their turn is transcribed, the AI classifies what they
  want and picks/fills one of a small set of approved reply categories (take a message, confirm
  a callback, decline to share something confidential, ask for clarification, close out) --
  deliberately not free-form generation, for reliability and for the privacy guarantee below.
- The greeting now reflects your actual availability status (Available / Busy / In a meeting /
  Custom) and callback window, set in the Availability section.

**Privacy enforcement -- the honest version**
- "100% accuracy" isn't something any AI/speech pipeline can truly guarantee -- transcription
  errors and LLM non-determinism are both real, irreducible sources of risk. What's actually
  implemented: every AI-generated reply is checked **in code**, after the AI produces it and
  before it's ever spoken, against your list of confidential phrases (Setup > "Never disclose").
  If a match is found, the reply is replaced with a safe canned response, regardless of what the
  AI tried to say. That's a real, verifiable guarantee at the code level -- much stronger than
  relying on a prompt instruction alone, even though no system can promise literal perfection.

**Outgoing calls**
- A lightweight background sync now also logs calls *you* make (number, time, duration) so the
  "Outgoing Calls" section isn't empty. No AI or recording involved for these, just a log.

## New setup steps

1. Run the (now longer) `supabase.sql` again -- `create table if not exists` is safe to re-run,
   it only adds the new tables (`contacts`, `privacy_rules`, `settings`) and extends `calls`.
2. Both Edge Functions (`process-call` and `respond-to-turn`) need deploying. If you already set
   up the `SUPABASE_ACCESS_TOKEN` secret and `SUPABASE_PROJECT_REF` variable from V1, the
   workflow now deploys both automatically -- nothing else to do.
3. Everything else (Config.kt, GitHub repo, build process) is unchanged from V1.

## New limitations worth knowing

- **Per-turn recordings, not one seamless file.** Each turn in a conversation is recorded to its
  own short audio file rather than one continuous recording -- avoids needing to run two audio
  capture pipelines at once or slice a file mid-call. The dashboard's "Play recording" plays
  whichever segment is attached to a call; there's no single gapless playback of a whole
  multi-turn conversation in V2.
- **"Blocked" isn't a true call block.** Without call-screening-role privileges (a bigger ask
  than this app requests), the phone still physically rings for a blocked number -- it just means
  the AI will never auto-answer or engage with that number.
- **All the V1 caveats still apply**: speakerphone-based recording (not a clean feed), best-effort
  programmatic hang-up, and the underlying Android 10+ restrictions on call-audio capture for
  non-default-dialer apps.
- **Nothing in this rewrite has been compiled or run.** This was an unusually large change --
  new database tables, a new Edge Function, a rewritten call state machine, a rewritten UI --
  built and reasoned through carefully, but GitHub Actions building it successfully is still the
  real first test, same as every project before this one.

---

# V3 — Zara persona, Settings reorg, back-button fix, persistent monitoring

## The honest part, up front

You asked to "route audio exclusively to the remote caller" and "fix the bot responding to the
local user." I can't fully deliver that, and I want to say why rather than build something that
quietly doesn't work:

True isolated two-way call audio (no echo of the AI's own voice, no crosstalk) requires the app
to be the phone's **default Dialer**, implementing `ConnectionService`/`InCallService` -- a much
bigger rewrite than anything in this project so far. And even that isn't a guarantee: actually
injecting synthesized speech into a live cellular call's audio path depends on baseband/OEM
support that isn't something any app can control from Android's application layer, regardless of
whether it's the default dialer. `CallScreeningService` (also requested) doesn't help with this
specific problem either -- it only decides whether to silence/reject/allow a call *before* it
connects, with no live audio access at all. I didn't implement it this round, because it also
requires claiming an exclusive system-wide role that could conflict with your phone's existing
spam/caller-ID app, for no benefit toward the actual audio-routing problem.

What I did fix: a real, separate bug likely contributing to "the bot hears itself" -- Android's
TTS `onDone` event can fire before the speaker physically finishes playing, so the mic could
catch the tail of Zara's own voice. There's now a short settle delay before each recording
starts, plus a best-effort attempt to attach Android's built-in echo canceller to the recording
session where the device supports it. Both reduce the problem. Neither replaces a clean call feed.

## What's new

- **Settings is now its own drawer item**, separate from Setup: availability, auto-answer, ring
  delay, priority contacts, and privacy rules all moved there. Setup keeps permissions, account,
  and diagnostics.
- **Zara's script, exactly as specified**: opens with "Hi, this is {assistant}, the personal
  assistant of {owner}," immediately asks the caller's preferred language, and closes with
  "Thank you for calling me. I will inform {owner} of the details, and he will call you back
  later." The names default to Zara/Shivay and are editable under Settings > Assistant identity.
- **Language-adaptive conversation**: the Edge Function detects the caller's stated language from
  their answer to that first question and responds in it for the rest of the call; the app
  switches its TTS voice to match when that language is installed on the phone.
- **Handling requests to speak to the owner directly**: added as an explicit case in the system
  prompt -- Zara explains he's unavailable per the current status, offers the callback window,
  and keeps trying to get the reason for the call, rather than just refusing.
- **The back-button bug is fixed, and here's what it actually was**: the drawer navigation had no
  `BackHandler` registered at all, so pressing back from any section other than the very first
  screen fell through to Android's default behavior for a single-Activity app -- which is to
  close the Activity entirely. That's exactly "navigating back terminates the app." Fixed with a
  proper `BackHandler`: back now closes an open drawer first, then returns to Setup from any
  other section, and only exits the app from Setup itself.
- **A persistent "AI Voicemail is monitoring calls" notification** (new `MonitoringService`,
  starts on sign-in and on boot) keeps the app's process alive in the background more reliably.
  This genuinely helps -- a running foreground service protects its process from being the first
  thing Android kills under memory pressure -- but it does not override a phone's own aggressive
  background-app manager (Vivo/OPPO/Xiaomi), which operates below what any app can control. Still
  need the battery/autostart settings covered in Setup alongside this.
- **Local caching of call records**: each list (Incoming/Outgoing/Recorded) now shows its
  last-known data immediately on open instead of a blank loading state, and keeps showing it if a
  refresh fails -- rather than the screen going blank on a flaky connection.

## Setup changes

Re-run `supabase.sql` (adds `assistant_name`/`owner_name` columns to `settings`, safe to re-run).
Everything else is unchanged.

## Still true from before

Nothing in this round has been compiled or run -- same as every round before it. Mid-session my
own working files were wiped by an environment reset partway through this change, so I rebuilt it
from the last zip I'd actually delivered you and redid everything from there; wanted to mention
that in case anything here doesn't quite match what I said I was doing live.
