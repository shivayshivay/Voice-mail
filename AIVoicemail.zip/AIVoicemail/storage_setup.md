# Storage bucket (for call recordings)

1. In Supabase: **Storage > New bucket**. Name it exactly `call_recordings`. Leave it **Private**.
2. **Storage > Policies**, select the `call_recordings` bucket, add a policy:
   - Operations: SELECT, INSERT
   - Target roles: `authenticated`
   - Policy definition: `true`

   (Keeps V1 simple: any signed-in user of this app can read/write files in the bucket. The
   Edge Function reads recordings using the service role key, which bypasses this anyway.)
