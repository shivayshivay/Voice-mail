package com.example.aivoicemail

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

class CallReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val state = i.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        @Suppress("DEPRECATION")
        val number = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        val prev = Prefs.callState(c)

        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                Prefs.setCallState(c, "RINGING")
                if (number.isNullOrBlank()) return
                Prefs.setRingingNumber(c, number)

                val priority = LocalRules.priorityFor(c, number)
                when (priority) {
                    "blocked" -> {
                        // AI won't engage with this number. Not a true silent network-level
                        // block (that needs call-screening-role privileges this app doesn't
                        // request) -- the phone still rings normally.
                        Prefs.setStatus(c, "call", "Blocked contact calling ($number) -- AI will not engage")
                        return
                    }
                    "vip" -> {
                        Prefs.setStatus(c, "call", "VIP calling ($number) -- ringing through normally, AI not involved")
                        return
                    }
                }

                val settings = LocalRules.settings(c)
                if (settings.auto_answer_enabled) {
                    val svc = Intent(c, AiCallService::class.java).apply {
                        action = AiCallService.ACTION_INCOMING
                        putExtra("number", number)
                        putExtra("priority", priority)
                        putExtra("ring_delay_seconds", settings.ring_delay_seconds)
                    }
                    ContextCompat.startForegroundService(c, svc)
                } else {
                    NotificationHelper.showManualAnswerNotification(c, number)
                }
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                Prefs.setCallState(c, "OFFHOOK")
                NotificationHelper.cancelIncomingCallNotification(c)
                if (Prefs.activeCallId(c).isBlank()) {
                    // Line went off-hook without the AI being the one who answered -- a human
                    // answered it normally. Tell the service to stand down if it was waiting.
                    val svc = Intent(c, AiCallService::class.java).setAction(AiCallService.ACTION_HUMAN_ANSWERED)
                    ContextCompat.startForegroundService(c, svc)
                }
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                Prefs.setCallState(c, "IDLE")
                NotificationHelper.cancelIncomingCallNotification(c)
                val action = if (prev != "IDLE" && Prefs.activeCallId(c).isNotBlank())
                    AiCallService.ACTION_CALL_ENDED else AiCallService.ACTION_HUMAN_ANSWERED
                ContextCompat.startForegroundService(c, Intent(c, AiCallService::class.java).setAction(action))
                Prefs.setRingingNumber(c, "")
            }
        }
    }
}
