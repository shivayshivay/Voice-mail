package com.example.aivoicemail

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

class CallReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val state = i.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        @Suppress("DEPRECATION")
        val number = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        val prev = Prefs.callState(c)

        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                Prefs.setCallState(c, "RINGING")
                if (!number.isNullOrBlank()) {
                    Prefs.setRingingNumber(c, number)
                    NotificationHelper.showIncomingCallNotification(c, number)
                }
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                Prefs.setCallState(c, "OFFHOOK")
                NotificationHelper.cancelIncomingCallNotification(c)
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                Prefs.setCallState(c, "IDLE")
                NotificationHelper.cancelIncomingCallNotification(c)
                if (prev != "IDLE" && Prefs.activeCallId(c).isNotBlank()) {
                    val svc = Intent(c, AiCallService::class.java).setAction(AiCallService.ACTION_CALL_ENDED)
                    ContextCompat.startForegroundService(c, svc)
                }
                Prefs.setRingingNumber(c, "")
            }
        }
    }
}
