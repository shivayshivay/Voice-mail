package com.example.aivoicemail

import android.app.Application

/** Starts the persistent monitoring notification as early as possible -- at process creation,
 *  not just when MainActivity happens to open. This matters because the process can also be
 *  started by the system purely to deliver a broadcast (e.g. BootReceiver, or CallReceiver after
 *  Android has killed and later restarted the app's process) without MainActivity ever running
 *  in that session; previously the foreground service only started from MainActivity.onCreate,
 *  so a process started that way had no protection against being killed again right away. */
class AiVoicemailApp : Application() {
    override fun onCreate() {
        super.onCreate()
        if (Prefs.accountVerified(this)) {
            MonitoringService.start(this)
        }
    }
}
