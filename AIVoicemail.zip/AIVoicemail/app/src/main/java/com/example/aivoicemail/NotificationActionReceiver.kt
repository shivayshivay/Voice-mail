package com.example.aivoicemail

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class NotificationActionReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_ANSWER_NOW = "com.example.aivoicemail.ANSWER_NOW"
        const val ACTION_CANCEL_AUTOANSWER = "com.example.aivoicemail.CANCEL_AUTOANSWER"
    }

    override fun onReceive(c: Context, i: Intent) {
        val number = i.getStringExtra("number") ?: Prefs.ringingNumber(c)
        NotificationHelper.cancelIncomingCallNotification(c)
        val svc = Intent(c, AiCallService::class.java).apply {
            action = when (i.action) {
                ACTION_ANSWER_NOW -> AiCallService.ACTION_ANSWER
                ACTION_CANCEL_AUTOANSWER -> AiCallService.ACTION_HUMAN_ANSWERED // reuse: "stand down"
                else -> return
            }
            putExtra("number", number)
        }
        ContextCompat.startForegroundService(c, svc)
    }
}
