package com.example.aivoicemail

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class NotificationActionReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_LET_AI_ANSWER = "com.example.aivoicemail.LET_AI_ANSWER"
    }

    override fun onReceive(c: Context, i: Intent) {
        if (i.action != ACTION_LET_AI_ANSWER) return
        val number = i.getStringExtra("number") ?: Prefs.ringingNumber(c)
        NotificationHelper.cancelIncomingCallNotification(c)
        val svc = Intent(c, AiCallService::class.java).apply {
            action = AiCallService.ACTION_ANSWER
            putExtra("number", number)
        }
        ContextCompat.startForegroundService(c, svc)
    }
}
