package com.example.aivoicemail

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService

/**
 * Always-on while signed in: a low-priority persistent notification whose only job is to keep
 * this app's process alive in the background, so the manifest-registered CallReceiver (which
 * needs a live process to run in) is less likely to be the process Android picks to kill under
 * memory pressure. This genuinely helps -- a running foreground service does protect its
 * process -- but it does NOT override a phone's own aggressive background-app manager (Vivo,
 * OPPO, Xiaomi, etc.), which operates at a level below what any app can control. Pair this with
 * the battery/autostart settings covered in Setup.
 */
class MonitoringService : LifecycleService() {
    companion object {
        const val CHANNEL = "aivm_monitoring"
        const val FG_ID = 9001

        fun start(c: Context) {
            ContextCompat.startForegroundService(c, Intent(c, MonitoringService::class.java))
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(FG_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        return START_STICKY
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("AI Voicemail is monitoring calls")
            .setContentText("Zara will answer calls per your Settings")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Background monitoring", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onBind(intent: Intent): IBinder? { super.onBind(intent); return null }
}
