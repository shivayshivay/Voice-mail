package com.example.aivoicemail

import android.content.Context
import android.provider.CallLog
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import io.github.jan.supabase.postgrest.from

/** Lightweight sync for calls YOU made (no AI involvement) -- just enough so "Outgoing Calls"
 *  in the dashboard shows real data, reusing the proven CallLog-reading approach from this
 *  project's sibling (DualPhoneMonitor). No transcript/summary for these, just the basics. */
object OutgoingCallSync {
    suspend fun syncNew(c: Context) {
        if (!SupabaseRepo.isSignedIn()) return
        val uid = SupabaseRepo.currentUid() ?: return
        val sinceId = Prefs.lastOutgoingId(c)
        var maxId = sinceId
        val projection = arrayOf(CallLog.Calls._ID, CallLog.Calls.NUMBER, CallLog.Calls.DATE, CallLog.Calls.DURATION, CallLog.Calls.TYPE)
        val cursor = c.contentResolver.query(
            CallLog.Calls.CONTENT_URI, projection,
            "${CallLog.Calls._ID} > ? AND ${CallLog.Calls.TYPE} = ?",
            arrayOf(sinceId.toString(), CallLog.Calls.OUTGOING_TYPE.toString()),
            "${CallLog.Calls._ID} ASC"
        ) ?: return

        cursor.use { cur ->
            val idI = cur.getColumnIndex(CallLog.Calls._ID)
            val numI = cur.getColumnIndex(CallLog.Calls.NUMBER)
            val dateI = cur.getColumnIndex(CallLog.Calls.DATE)
            val durI = cur.getColumnIndex(CallLog.Calls.DURATION)
            while (cur.moveToNext()) {
                val id = cur.getLong(idI)
                val row = CallRow(
                    id = "outgoing_$id",
                    user_id = uid,
                    number = cur.getString(numI) ?: "Unknown",
                    started_at = cur.getLong(dateI),
                    duration_seconds = cur.getInt(durI),
                    status = "done",
                    direction = "outgoing"
                )
                try { SupabaseRepo.postgrest().from("calls").upsert(row) } catch (_: Exception) { }
                if (id > maxId) maxId = id
            }
        }
        if (maxId > sinceId) Prefs.setLastOutgoingId(c, maxId)
    }

    class Worker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
        override suspend fun doWork(): Result = try {
            syncNew(applicationContext); Result.success()
        } catch (e: Exception) { Result.retry() }
    }
}
