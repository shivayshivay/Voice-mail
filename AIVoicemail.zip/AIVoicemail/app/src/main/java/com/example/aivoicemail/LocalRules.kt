package com.example.aivoicemail

import android.content.Context
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/** Reads the locally-cached contacts/settings (synced from Supabase whenever the dashboard
 *  loads successfully) so an incoming call can be routed instantly -- waiting on a network
 *  call at the exact moment the phone is ringing isn't acceptable. */
object LocalRules {
    private val json = Json { ignoreUnknownKeys = true }

    fun priorityFor(c: Context, number: String): String {
        val contacts = try {
            json.decodeFromString<List<ContactRow>>(Prefs.contactsCacheJson(c))
        } catch (_: Exception) { emptyList() }
        val match = contacts.firstOrNull { sameNumber(it.number, number) }
        return match?.priority ?: "normal"
    }

    fun settings(c: Context): SettingsRow {
        val raw = Prefs.settingsCacheJson(c)
        if (raw.isBlank()) return SettingsRow(user_id = "")
        return try { json.decodeFromString<SettingsRow>(raw) } catch (_: Exception) { SettingsRow(user_id = "") }
    }

    fun refreshContactsCache(c: Context, contacts: List<ContactRow>) {
        Prefs.setContactsCacheJson(c, json.encodeToString(contacts))
    }

    fun refreshSettingsCache(c: Context, settings: SettingsRow) {
        Prefs.setSettingsCacheJson(c, json.encodeToString(settings))
    }

    private fun sameNumber(a: String, b: String): Boolean {
        val x = a.filter { it.isDigit() }.takeLast(10)
        val y = b.filter { it.isDigit() }.takeLast(10)
        return x.isNotEmpty() && x == y
    }
}
