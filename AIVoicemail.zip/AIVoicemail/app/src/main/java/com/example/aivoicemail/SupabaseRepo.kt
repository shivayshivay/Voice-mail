package com.example.aivoicemail

import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.OtpType
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.OTP
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.functions.Functions
import io.github.jan.supabase.functions.functions
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.storage.Storage
import io.github.jan.supabase.storage.storage

object SupabaseRepo {
    val client by lazy {
        createSupabaseClient(
            supabaseUrl = Config.SUPABASE_URL,
            supabaseKey = Config.SUPABASE_ANON_KEY
        ) {
            install(Auth)
            install(Postgrest)
            install(Storage)
            install(Functions)
        }
    }

    suspend fun sendEmailOtp(email: String) {
        client.auth.signInWith(OTP) { this.email = email }
    }

    suspend fun verifyEmailOtp(email: String, token: String): String {
        client.auth.verifyEmailOtp(type = OtpType.Email.EMAIL, email = email, token = token)
        return client.auth.currentUserOrNull()?.id
            ?: error("Code accepted but no session was created -- try sending a new code")
    }

    fun currentUid(): String? = client.auth.currentUserOrNull()?.id
    fun currentEmail(): String? = client.auth.currentUserOrNull()?.email

    suspend fun signOut() { try { client.auth.signOut() } catch (_: Exception) { } }

    private suspend fun currentUidAwait(): String? {
        client.auth.awaitInitialization()
        return client.auth.currentUserOrNull()?.id
    }

    suspend fun isSignedIn(): Boolean = currentUidAwait() != null

    suspend fun requireSignedIn(): String =
        currentUidAwait() ?: error("Not signed in -- verify your email first")

    fun postgrest() = client.postgrest
    fun storage() = client.storage
    fun functions() = client.functions
}
