package com.example.aivoicemail

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object NotificationHelper {
    const val CHANNEL_INCOMING = "aivm_incoming"
    const val CHANNEL_STATUS = "aivm_status"
    const val CHANNEL_DONE = "aivm_done"
    const val INCOMING_NOTIF_ID = 5001

    fun createChannels(c: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL_INCOMING, "Incoming calls", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CHANNEL_STATUS, "AI call status", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CHANNEL_DONE, "Call ready in dashboard", NotificationManager.IMPORTANCE_DEFAULT))
    }

    private fun hasPermission(c: Context): Boolean {
        if (Build.VERSION.SDK_INT < 33) return true
        return ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }

    private fun broadcast(c: Context, action: String, number: String): PendingIntent {
        val i = Intent(c, NotificationActionReceiver::class.java).apply {
            this.action = action
            putExtra("number", number)
        }
        return PendingIntent.getBroadcast(c, action.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** Manual mode (auto-answer disabled in settings): simple "let AI answer" prompt. */
    fun showManualAnswerNotification(c: Context, number: String) {
        createChannels(c)
        val n = NotificationCompat.Builder(c, CHANNEL_INCOMING)
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle("Incoming call: $number")
            .setContentText("Tap to let the AI answer")
            .addAction(0, "Let AI Answer", broadcast(c, NotificationActionReceiver.ACTION_ANSWER_NOW, number))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setOngoing(true)
            .build()
        if (hasPermission(c)) NotificationManagerCompat.from(c).notify(INCOMING_NOTIF_ID, n)
    }

    /** Auto-answer mode: tells you it's about to happen and lets you answer immediately or
     *  cancel it (so you can take the call yourself the normal way instead). */
    fun showAutoAnswerPendingNotification(c: Context, number: String, delaySeconds: Int) {
        createChannels(c)
        val n = NotificationCompat.Builder(c, CHANNEL_INCOMING)
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle("Incoming call: $number")
            .setContentText("AI will answer in ${delaySeconds}s unless you answer it yourself")
            .addAction(0, "Answer now (AI)", broadcast(c, NotificationActionReceiver.ACTION_ANSWER_NOW, number))
            .addAction(0, "Don't let AI answer", broadcast(c, NotificationActionReceiver.ACTION_CANCEL_AUTOANSWER, number))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setOngoing(true)
            .build()
        if (hasPermission(c)) NotificationManagerCompat.from(c).notify(INCOMING_NOTIF_ID, n)
    }

    fun cancelIncomingCallNotification(c: Context) {
        NotificationManagerCompat.from(c).cancel(INCOMING_NOTIF_ID)
    }

    fun notifyCallReady(c: Context, number: String) {
        if (!hasPermission(c)) return
        val n = NotificationCompat.Builder(c, CHANNEL_DONE)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle("Call summary ready")
            .setContentText("$number -- check the dashboard")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(c).notify(System.currentTimeMillis().toInt(), n)
    }
}
