package com.example.aivoicemail

import android.app.Notification
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.telecom.TelecomManager
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

/**
 * Answers a call, routes it to speakerphone, greets the caller via on-device TTS, records
 * everything the mic picks up (which includes both our TTS and the caller's voice, acoustically
 * -- see README for why this approach instead of a clean call-audio feed), then uploads and
 * kicks off server-side transcription/summary once the call ends.
 *
 * Two deliberately best-effort pieces, both flagged clearly rather than silently assumed to
 * work: ending the call programmatically (TelecomManager.endCall() isn't guaranteed for a
 * non-default-dialer app on every Android version), and the recording itself (same Android 10+
 * call-audio restrictions covered in this project's earlier call-recording feature).
 */
class AiCallService : LifecycleService() {
    companion object {
        const val ACTION_ANSWER = "com.example.aivoicemail.ACTION_ANSWER"
        const val ACTION_CALL_ENDED = "com.example.aivoicemail.ACTION_CALL_ENDED"
        const val FG_ID = 7001
        const val MAX_RECORD_MS = 5 * 60 * 1000L // safety cap: 5 minutes
    }

    private var recorder: MediaRecorder? = null
    private var outFile: File? = null
    private var startedAtMs = 0L
    private var number: String = ""
    private var tts: TextToSpeech? = null
    private var audioManager: AudioManager? = null
    private var previousSpeakerState = false

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createChannels(this)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_ANSWER -> handleAnswer(intent.getStringExtra("number") ?: "Unknown")
            ACTION_CALL_ENDED -> handleCallEnded()
            else -> stopSelfSafely()
        }
        return START_NOT_STICKY
    }

    private fun handleAnswer(num: String) {
        number = num
        val callId = "call_${System.currentTimeMillis()}"
        Prefs.setActiveCallId(this, callId)
        startForeground(FG_ID, buildStatusNotification("Answering $num..."))

        try {
            val tm = getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            tm?.acceptRingingCall()
            Prefs.setStatus(this, "call", "Answered $num")
        } catch (e: Exception) {
            Prefs.setStatus(this, "call", "Failed to answer -- ${e.message ?: e::class.simpleName}")
            Prefs.setActiveCallId(this, "")
            stopSelfSafely()
            return
        }

        audioManager?.let {
            previousSpeakerState = it.isSpeakerphoneOn
            it.mode = AudioManager.MODE_IN_COMMUNICATION
            it.isSpeakerphoneOn = true
        }

        startedAtMs = System.currentTimeMillis()
        startRecording(callId)

        Handler(Looper.getMainLooper()).postDelayed({ speakGreeting() }, 700)
        Handler(Looper.getMainLooper()).postDelayed({
            if (Prefs.activeCallId(this) == callId) handleCallEnded()
        }, MAX_RECORD_MS)
    }

    private fun speakGreeting() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                tts?.speak(
                    "Hi, you've reached an A I assistant answering this call. " +
                        "Please leave your message after the tone, and it will be passed along.",
                    TextToSpeech.QUEUE_FLUSH, null, "greeting"
                )
            } else {
                Prefs.setStatus(this, "tts", "Text-to-speech engine failed to initialize")
            }
        }
    }

    private fun startRecording(callId: String) {
        val dir = File(cacheDir, "calls").apply { mkdirs() }
        val file = File(dir, "$callId.m4a")
        outFile = file
        try {
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOutputFile(file.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            Prefs.setStatus(this, "recording", "Recording started")
        } catch (e: Exception) {
            recorder = null
            Prefs.setStatus(this, "recording", "Failed to start -- ${e.message ?: e::class.simpleName} (this phone/firmware likely blocks call-audio capture for non-dialer apps)")
        }
    }

    private fun handleCallEnded() {
        val callId = Prefs.activeCallId(this)
        if (callId.isBlank()) return
        Prefs.setActiveCallId(this, "")

        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        tts = null

        val durationSeconds = ((System.currentTimeMillis() - startedAtMs) / 1000).toInt()
        try { recorder?.apply { stop(); release() } } catch (_: Exception) { }
        recorder = null

        try {
            val tm = getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            @Suppress("DEPRECATION")
            tm?.endCall()
        } catch (e: Exception) {
            Prefs.setStatus(this, "hangup", "Could not hang up automatically -- ${e.message ?: e::class.simpleName} (end it from the normal call screen if it's still connected)")
        }

        audioManager?.let {
            it.isSpeakerphoneOn = previousSpeakerState
            it.mode = AudioManager.MODE_NORMAL
        }

        val file = outFile
        if (file != null && file.exists() && file.length() > 0) {
            lifecycleScope.launch(Dispatchers.IO) { uploadAndProcess(callId, file, durationSeconds) }
        } else {
            Prefs.setStatus(this, "recording", "No audio file produced for this call -- nothing to upload")
            stopSelfSafely()
        }
    }

    private suspend fun uploadAndProcess(callId: String, file: File, durationSeconds: Int) {
        try {
            val uid = SupabaseRepo.requireSignedIn()
            val path = "$callId.m4a"
            SupabaseRepo.storage().from("call_recordings").upload(path, file.readBytes())

            val row = CallRow(
                id = callId,
                user_id = uid,
                number = number,
                started_at = startedAtMs,
                duration_seconds = durationSeconds,
                recording_path = path,
                status = "recorded"
            )
            SupabaseRepo.postgrest().from("calls").upsert(row)
            Prefs.setStatus(this@AiCallService, "upload", "Uploaded OK -- $durationSeconds s")

            try {
                SupabaseRepo.functions().invoke("process-call", body = mapOf("call_id" to callId))
                SupabaseRepo.postgrest().from("calls").update({ set("status", "processing") }) { filter { eq("id", callId) } }
                Prefs.setStatus(this@AiCallService, "ai", "Transcription/summary requested")
            } catch (e: Exception) {
                Prefs.setStatus(this@AiCallService, "ai", "Could not trigger AI processing -- ${e.message ?: e::class.simpleName}")
            }

            NotificationHelper.notifyCallReady(this@AiCallService, number)
        } catch (e: Exception) {
            Prefs.setStatus(this@AiCallService, "upload", "Upload failed -- ${e.message ?: e::class.simpleName}")
        } finally {
            file.delete()
            stopSelfSafely()
        }
    }

    private fun stopSelfSafely() {
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) { }
        stopSelf()
    }

    private fun buildStatusNotification(text: String): Notification =
        NotificationCompat.Builder(this, NotificationHelper.CHANNEL_STATUS)
            .setSmallIcon(android.R.drawable.presence_audio_online)
            .setContentTitle("AI handling call")
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    override fun onBind(intent: Intent): IBinder? { super.onBind(intent); return null }
}
