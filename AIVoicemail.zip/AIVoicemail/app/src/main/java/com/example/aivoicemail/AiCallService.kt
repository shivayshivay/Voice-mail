package com.example.aivoicemail

import android.app.Notification
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.TelecomManager
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import io.github.jan.supabase.postgrest.from
import io.ktor.client.statement.bodyAsText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.Locale

/**
 * State machine: RINGING (optionally with an overridable auto-answer countdown) -> ANSWERED
 * -> a bounded turn loop (greeting, then up to MAX_CALLER_TURNS exchanges, each turn recorded,
 * transcribed+classified+replied-to server-side via the respond-to-turn Edge Function) -> ended
 * -> upload/finalize.
 *
 * Deliberate simplification, documented in the README: each turn is recorded to its own short
 * audio file rather than one continuous recording, which avoids needing to run two audio
 * capture pipelines at once or slice a single file mid-stream. The tradeoff: there's no single
 * seamless "play the whole call" file, only per-turn playback. Also, as covered in the project's
 * earlier call-recording feature: non-default-dialer apps can't get a clean call-audio feed, so
 * this is speakerphone + mic, not a clean two-party feed, and ending the call programmatically
 * is best-effort, not guaranteed on every Android version.
 */
class AiCallService : LifecycleService() {
    companion object {
        const val ACTION_INCOMING = "com.example.aivoicemail.ACTION_INCOMING"
        const val ACTION_ANSWER = "com.example.aivoicemail.ACTION_ANSWER"
        const val ACTION_HUMAN_ANSWERED = "com.example.aivoicemail.ACTION_HUMAN_ANSWERED"
        const val ACTION_CALL_ENDED = "com.example.aivoicemail.ACTION_CALL_ENDED"
        const val FG_ID = 7001
        const val MAX_RECORD_MS = 5 * 60 * 1000L
        const val TURN_RECORD_MS = 8000L
        const val MAX_CALLER_TURNS = 3
        // Android's TTS onDone can fire slightly before the speaker physically finishes
        // playing -- without this gap, the mic can catch the tail of the AI's own voice and
        // transcribe itself. Doesn't eliminate crosstalk (see class doc), just reduces it.
        const val TTS_SETTLE_MS = 450L
    }

    private var recorder: MediaRecorder? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var currentSegmentFile: File? = null
    private var callerTurnCount = 0
    private var startedAtMs = 0L
    private var number = ""
    private var priority = "normal"
    private var callId = ""
    private var tts: TextToSpeech? = null
    private var audioManager: AudioManager? = null
    private var previousSpeakerState = false
    private var pendingAutoAnswerRunnable: Runnable? = null
    private var safetyCapRunnable: Runnable? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val json = Json { ignoreUnknownKeys = true }

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createChannels(this)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        startForeground(FG_ID, buildStatusNotification("Ready"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_INCOMING -> handleIncoming(
                intent.getStringExtra("number") ?: "Unknown",
                intent.getStringExtra("priority") ?: "normal",
                intent.getIntExtra("ring_delay_seconds", 8)
            )
            ACTION_ANSWER -> {
                cancelPendingAutoAnswer()
                proceedToAnswer(intent.getStringExtra("number") ?: Prefs.ringingNumber(this))
            }
            ACTION_HUMAN_ANSWERED -> {
                cancelPendingAutoAnswer()
                if (Prefs.activeCallId(this).isBlank()) stopSelfSafely()
            }
            ACTION_CALL_ENDED -> handleCallEnded()
            else -> stopSelfSafely()
        }
        return START_NOT_STICKY
    }

    private fun handleIncoming(num: String, pri: String, delaySeconds: Int) {
        number = num
        priority = pri
        updateStatusNotification("Incoming: $num")
        NotificationHelper.showAutoAnswerPendingNotification(this, num, delaySeconds)
        val r = Runnable { proceedToAnswer(num) }
        pendingAutoAnswerRunnable = r
        mainHandler.postDelayed(r, delaySeconds * 1000L)
    }

    private fun cancelPendingAutoAnswer() {
        pendingAutoAnswerRunnable?.let { mainHandler.removeCallbacks(it) }
        pendingAutoAnswerRunnable = null
        NotificationHelper.cancelIncomingCallNotification(this)
    }

    private fun proceedToAnswer(num: String) {
        cancelPendingAutoAnswer()
        if (Prefs.callState(this) != "RINGING") {
            Prefs.setStatus(this, "call", "Skipped auto-answer -- call state already changed")
            stopSelfSafely()
            return
        }
        number = num
        callId = "call_${System.currentTimeMillis()}"
        callerTurnCount = 0
        Prefs.setActiveCallId(this, callId)

        try {
            val tm = getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            tm?.acceptRingingCall()
            Prefs.setStatus(this, "call", "Answered $num")
        } catch (e: Exception) {
            Prefs.setStatus(this, "call", "Failed to answer -- ${e.message ?: e::class.simpleName}")
            Prefs.setActiveCallId(this, "")
            stopSelfSafely()
            return
        }

        audioManager?.let {
            previousSpeakerState = it.isSpeakerphoneOn
            it.mode = AudioManager.MODE_IN_COMMUNICATION
            it.isSpeakerphoneOn = true
        }

        startedAtMs = System.currentTimeMillis()
        safetyCapRunnable = Runnable { if (Prefs.activeCallId(this) == callId) handleCallEnded() }
        mainHandler.postDelayed(safetyCapRunnable!!, MAX_RECORD_MS)

        mainHandler.postDelayed({ speakGreetingThenListen() }, 700)
    }

    private fun speakGreetingThenListen() {
        if (Prefs.activeCallId(this) != callId) return
        val settings = LocalRules.settings(this)
        // Fixed opening script, as specified: identify as the assistant, then immediately ask
        // for a preferred language before anything else. Availability status (busy/in a
        // meeting/custom) still shapes what gets said in LATER turns via the Edge Function's
        // system prompt, rather than the opening line itself.
        val greeting = "Hi, this is ${settings.assistant_name}, the personal assistant of ${settings.owner_name}. " +
            "What language would you prefer to speak in?"
        speak(greeting) { startCallerTurn() }
    }

    private fun startCallerTurn() {
        if (Prefs.activeCallId(this) != callId) return
        if (callerTurnCount >= MAX_CALLER_TURNS) {
            closeOutCall(closingLine())
            return
        }
        // Give any tail of the AI's own speech a moment to finish before the mic starts
        // listening -- see TTS_SETTLE_MS doc. Reduces, doesn't eliminate, self-pickup.
        mainHandler.postDelayed({ beginRecordingTurn() }, TTS_SETTLE_MS)
    }

    private fun closingLine(): String {
        val settings = LocalRules.settings(this)
        return "Thank you for calling me. I will inform ${settings.owner_name} of the details, " +
            "and he will call you back later."
    }

    private fun beginRecordingTurn() {
        if (Prefs.activeCallId(this) != callId) return
        val dir = File(cacheDir, "calls").apply { mkdirs() }
        val segFile = File(dir, "${callId}_seg${callerTurnCount}.m4a")
        currentSegmentFile = segFile
        try {
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOutputFile(segFile.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            attachEchoCancelerBestEffort(r)
            Prefs.setStatus(this, "recording", "Listening (turn ${callerTurnCount + 1})")
        } catch (e: Exception) {
            recorder = null
            Prefs.setStatus(this, "recording", "Failed to start -- ${e.message ?: e::class.simpleName}")
            closeOutCall("Sorry, I'm having trouble hearing you. I'll make sure this is passed along. Goodbye.")
            return
        }
        mainHandler.postDelayed({ finishCallerTurn() }, TURN_RECORD_MS)
    }

    /** Best-effort only: AcousticEchoCanceler isn't available on every device, and even where
     *  it is, it was designed for VoIP-style duplex audio, not this speakerphone setup -- may
     *  help with self-pickup, isn't a substitute for a clean call-audio feed. */
    private fun attachEchoCancelerBestEffort(r: MediaRecorder) {
        try {
            if (!AcousticEchoCanceler.isAvailable()) return
            val sessionId = r.audioSessionId
            if (sessionId == 0) return
            echoCanceler?.release()
            echoCanceler = AcousticEchoCanceler.create(sessionId)?.apply { enabled = true }
        } catch (_: Exception) {
            // No echo cancellation on this device/session -- not fatal, just less mitigation.
        }
    }

    private fun finishCallerTurn() {
        if (Prefs.activeCallId(this) != callId) return
        val file = currentSegmentFile
        try { echoCanceler?.release() } catch (_: Exception) { }
        echoCanceler = null
        try { recorder?.apply { stop(); release() } } catch (_: Exception) { }
        recorder = null
        callerTurnCount++

        if (file == null || !file.exists() || file.length() == 0L) {
            closeOutCall("I didn't catch that, but I'll note that someone called. Goodbye.")
            return
        }
        lifecycleScope.launch(Dispatchers.IO) { processTurn(file) }
    }

    private suspend fun processTurn(file: File) {
        try {
            val uid = SupabaseRepo.requireSignedIn()
            val path = "$callId/${file.name}"
            SupabaseRepo.storage().from("call_recordings").upload(path, file.readBytes())

            SupabaseRepo.postgrest().from("calls").upsert(
                CallRow(
                    id = callId, user_id = uid, number = number, started_at = startedAtMs,
                    status = "in_progress", direction = "incoming", priority = priority
                )
            )

            val response = SupabaseRepo.functions().invoke(
                "respond-to-turn",
                body = mapOf("call_id" to callId, "segment_path" to path, "turn_index" to (callerTurnCount - 1))
            )
            val parsed = json.decodeFromString<TurnResponse>(response.bodyAsText())
            withContext(Dispatchers.Main) {
                Prefs.setStatus(this@AiCallService, "ai", "Turn $callerTurnCount: ${parsed.reply_text}")
                applyLanguageBestEffort(parsed.language_code)
                speak(parsed.reply_text) {
                    if (parsed.end_call) handleCallEnded() else startCallerTurn()
                }
            }
        } catch (e: Exception) {
            Prefs.setStatus(this, "ai", "Turn processing failed -- ${e.message ?: e::class.simpleName}")
            withContext(Dispatchers.Main) {
                closeOutCall("Sorry, I'm having trouble right now. I'll make sure this is passed along. Goodbye.")
            }
        } finally {
            file.delete()
        }
    }

    private fun closeOutCall(finalLine: String) {
        speak(finalLine) { handleCallEnded() }
    }

    /** Switches the TTS voice to the caller's stated language, when the device has that
     *  language installed. Best-effort: if it's not available, Android's TTS silently falls
     *  back to whatever voice is already set rather than failing outright. */
    private fun applyLanguageBestEffort(languageCode: String?) {
        if (languageCode.isNullOrBlank() || tts == null) return
        try {
            val locale = Locale.forLanguageTag(languageCode)
            val result = tts?.setLanguage(locale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Prefs.setStatus(this, "tts", "Language '$languageCode' not available on this device -- continuing in default voice")
            }
        } catch (_: Exception) {
            // Unrecognized language tag -- ignore, keep current voice.
        }
    }

    private fun speak(text: String, onDone: () -> Unit) {
        if (tts == null) {
            tts = TextToSpeech(this) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.language = Locale.getDefault()
                    speakNow(text, onDone)
                } else {
                    Prefs.setStatus(this, "tts", "Text-to-speech engine failed to initialize")
                    onDone()
                }
            }
        } else {
            speakNow(text, onDone)
        }
    }

    private fun speakNow(text: String, onDone: () -> Unit) {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { mainHandler.post(onDone) }
            @Deprecated("deprecated in platform API, still required to override")
            override fun onError(utteranceId: String?) { mainHandler.post(onDone) }
        })
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u_${System.currentTimeMillis()}")
    }

    private fun handleCallEnded() {
        val id = Prefs.activeCallId(this)
        if (id.isBlank()) { stopSelfSafely(); return }
        Prefs.setActiveCallId(this, "")
        cancelPendingAutoAnswer()
        safetyCapRunnable?.let { mainHandler.removeCallbacks(it) }

        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        tts = null
        try { echoCanceler?.release() } catch (_: Exception) { }
        echoCanceler = null
        try { recorder?.apply { stop(); release() } } catch (_: Exception) { }
        recorder = null

        val durationSeconds = ((System.currentTimeMillis() - startedAtMs) / 1000).toInt()

        try {
            val tm = getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            @Suppress("DEPRECATION")
            tm?.endCall()
        } catch (e: Exception) {
            Prefs.setStatus(this, "hangup", "Could not hang up automatically -- ${e.message ?: e::class.simpleName}")
        }

        audioManager?.let {
            it.isSpeakerphoneOn = previousSpeakerState
            it.mode = AudioManager.MODE_NORMAL
        }

        lifecycleScope.launch(Dispatchers.IO) { finalizeCall(id, durationSeconds) }
    }

    private suspend fun finalizeCall(id: String, durationSeconds: Int) {
        try {
            SupabaseRepo.requireSignedIn()
            SupabaseRepo.postgrest().from("calls").update(
                { set("duration_seconds", durationSeconds); set("status", "processing") }
            ) { filter { eq("id", id) } }
            try {
                SupabaseRepo.functions().invoke("process-call", body = mapOf("call_id" to id))
                Prefs.setStatus(this@AiCallService, "ai", "Final summary requested")
            } catch (e: Exception) {
                Prefs.setStatus(this@AiCallService, "ai", "Could not trigger final summary -- ${e.message ?: e::class.simpleName}")
            }
            NotificationHelper.notifyCallReady(this@AiCallService, number)
        } catch (e: Exception) {
            Prefs.setStatus(this@AiCallService, "upload", "Finalize failed -- ${e.message ?: e::class.simpleName}")
        } finally {
            stopSelfSafely()
        }
    }

    private fun stopSelfSafely() {
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) { }
        stopSelf()
    }

    private fun buildStatusNotification(text: String): Notification =
        NotificationCompat.Builder(this, NotificationHelper.CHANNEL_STATUS)
            .setSmallIcon(android.R.drawable.presence_audio_online)
            .setContentTitle("AI call assistant")
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    private fun updateStatusNotification(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(FG_ID, buildStatusNotification(text))
    }

    override fun onBind(intent: Intent): IBinder? { super.onBind(intent); return null }
}

@Serializable
data class TurnResponse(
    val reply_text: String,
    val end_call: Boolean = false,
    val language_code: String? = null // BCP-47-ish, e.g. "es", "hi", "fr" -- best-effort
)
