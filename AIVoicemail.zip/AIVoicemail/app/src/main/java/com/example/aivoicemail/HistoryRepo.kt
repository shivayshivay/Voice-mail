package com.example.aivoicemail

import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order
import io.ktor.http.isSuccess
import kotlin.time.Duration.Companion.hours

object HistoryRepo {
    suspend fun fetchCalls(direction: String? = null): List<CallRow> =
        SupabaseRepo.postgrest().from("calls").select {
            order("started_at", Order.DESCENDING)
            if (direction != null) filter { eq("direction", direction) }
            limit(200L)
        }.decodeList<CallRow>()

    /** For a call stuck between "recorded"/"in_progress"/"processing" and "done" (e.g. the
     *  Edge Function failed partway through) -- re-triggers process-call so it isn't stuck
     *  forever with no way to recover without re-running the whole call. */
    suspend fun retryProcessing(callId: String) {
        SupabaseRepo.requireSignedIn()
        SupabaseRepo.postgrest().from("calls").update(
            { set("status", "processing") }
        ) { filter { eq("id", callId) } }
        val response = SupabaseRepo.functions().invoke("process-call", body = mapOf("call_id" to callId))
        if (!response.status.isSuccess()) {
            SupabaseRepo.postgrest().from("calls").update(
                { set("status", "failed") }
            ) { filter { eq("id", callId) } }
            error("process-call returned HTTP ${response.status.value}")
        }
    }

    suspend fun recordingUrl(path: String): String =
        SupabaseRepo.storage().from("call_recordings").createSignedUrl(path, 1.hours)

    suspend fun fetchContacts(): List<ContactRow> =
        SupabaseRepo.postgrest().from("contacts").select().decodeList<ContactRow>()

    suspend fun upsertContact(row: ContactRow) {
        val uid = SupabaseRepo.requireSignedIn()
        SupabaseRepo.postgrest().from("contacts").upsert(row.copy(user_id = uid))
    }

    suspend fun deleteContact(id: String) {
        SupabaseRepo.postgrest().from("contacts").delete { filter { eq("id", id) } }
    }

    suspend fun fetchPrivacyRules(): List<PrivacyRuleRow> =
        SupabaseRepo.postgrest().from("privacy_rules").select().decodeList<PrivacyRuleRow>()

    suspend fun addPrivacyRule(phrase: String) {
        val uid = SupabaseRepo.requireSignedIn()
        SupabaseRepo.postgrest().from("privacy_rules").insert(PrivacyRuleRow(user_id = uid, phrase = phrase))
    }

    suspend fun deletePrivacyRule(id: String) {
        SupabaseRepo.postgrest().from("privacy_rules").delete { filter { eq("id", id) } }
    }

    suspend fun fetchSettings(): SettingsRow? {
        val uid = SupabaseRepo.requireSignedIn()
        return SupabaseRepo.postgrest().from("settings").select {
            filter { eq("user_id", uid) }
        }.decodeList<SettingsRow>().firstOrNull()
    }

    suspend fun saveSettings(row: SettingsRow) {
        SupabaseRepo.postgrest().from("settings").upsert(row)
    }
}
