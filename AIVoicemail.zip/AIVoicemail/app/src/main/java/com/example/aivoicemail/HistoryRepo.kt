package com.example.aivoicemail

import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order
import kotlin.time.Duration.Companion.hours

object HistoryRepo {
    suspend fun fetchCalls(): List<CallRow> =
        SupabaseRepo.postgrest().from("calls").select {
            order("started_at", Order.DESCENDING)
            limit(200L)
        }.decodeList<CallRow>()

    suspend fun recordingUrl(path: String): String =
        SupabaseRepo.storage().from("call_recordings").createSignedUrl(path, 1.hours)
}
