package com.example.aivoicemail

import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order
import kotlin.time.Duration.Companion.hours

object HistoryRepo {
    suspend fun fetchCalls(direction: String? = null): List<CallRow> =
        SupabaseRepo.postgrest().from("calls").select {
            order("started_at", Order.DESCENDING)
            if (direction != null) filter { eq("direction", direction) }
            limit(200L)
        }.decodeList<CallRow>()

    suspend fun recordingUrl(path: String): String =
        SupabaseRepo.storage().from("call_recordings").createSignedUrl(path, 1.hours)

    suspend fun fetchContacts(): List<ContactRow> =
        SupabaseRepo.postgrest().from("contacts").select().decodeList<ContactRow>()

    suspend fun upsertContact(row: ContactRow) {
        val uid = SupabaseRepo.requireSignedIn()
        SupabaseRepo.postgrest().from("contacts").upsert(row.copy(user_id = uid))
    }

    suspend fun deleteContact(id: String) {
        SupabaseRepo.postgrest().from("contacts").delete { filter { eq("id", id) } }
    }

    suspend fun fetchPrivacyRules(): List<PrivacyRuleRow> =
        SupabaseRepo.postgrest().from("privacy_rules").select().decodeList<PrivacyRuleRow>()

    suspend fun addPrivacyRule(phrase: String) {
        val uid = SupabaseRepo.requireSignedIn()
        SupabaseRepo.postgrest().from("privacy_rules").insert(PrivacyRuleRow(user_id = uid, phrase = phrase))
    }

    suspend fun deletePrivacyRule(id: String) {
        SupabaseRepo.postgrest().from("privacy_rules").delete { filter { eq("id", id) } }
    }

    suspend fun fetchSettings(): SettingsRow? {
        val uid = SupabaseRepo.requireSignedIn()
        return SupabaseRepo.postgrest().from("settings").select {
            filter { eq("user_id", uid) }
        }.decodeList<SettingsRow>().firstOrNull()
    }

    suspend fun saveSettings(row: SettingsRow) {
        SupabaseRepo.postgrest().from("settings").upsert(row)
    }
}
