package com.example.aivoicemail

import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit

object WorkScheduler {
    fun schedulePeriodic(c: Context) {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val req = PeriodicWorkRequestBuilder<OutgoingCallSync.Worker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints).build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(
            "outgoing-call-sync", ExistingPeriodicWorkPolicy.KEEP, req
        )
    }

    fun runOnceNow(c: Context) {
        WorkManager.getInstance(c).enqueue(OneTimeWorkRequestBuilder<OutgoingCallSync.Worker>().build())
    }
}
