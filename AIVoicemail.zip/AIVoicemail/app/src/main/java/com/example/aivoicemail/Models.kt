package com.example.aivoicemail

import kotlinx.serialization.Serializable

@Serializable
data class CallRow(
    val id: String,
    val user_id: String? = null,
    val number: String,
    val started_at: Long,
    val duration_seconds: Int = 0,
    val recording_path: String? = null,
    val status: String = "recorded", // recorded -> processing -> done | failed
    val transcript: String? = null,
    val summary: String? = null,
    val urgent: Boolean? = null,
    val extracted: String? = null // JSON string: names/dates/phone numbers/suggested callback
)
