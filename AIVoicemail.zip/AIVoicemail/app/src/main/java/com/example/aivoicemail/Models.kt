package com.example.aivoicemail

import kotlinx.serialization.Serializable

@Serializable
data class CallRow(
    val id: String,
    val user_id: String? = null,
    val number: String,
    val started_at: Long,
    val duration_seconds: Int = 0,
    val recording_path: String? = null,
    val status: String = "recorded", // recorded -> processing -> done | failed
    val transcript: String? = null,
    val summary: String? = null,
    val urgent: Boolean? = null,
    val extracted: String? = null, // JSON string: names/dates/phone numbers/suggested callback
    val direction: String = "incoming", // incoming | outgoing
    val priority: String? = null, // vip | normal | blocked, as of call time
    val turns: String? = null // JSON array: [{speaker, text, ts}, ...]
)

@Serializable
data class ContactRow(
    val id: String? = null,
    val user_id: String? = null,
    val number: String,
    val name: String = "",
    val priority: String = "normal" // vip | normal | blocked
)

@Serializable
data class PrivacyRuleRow(
    val id: String? = null,
    val user_id: String? = null,
    val phrase: String
)

@Serializable
data class SettingsRow(
    val user_id: String,
    val status: String = "available", // available | busy | in_meeting | custom
    val custom_message: String = "",
    val callback_window: String = "later today",
    val auto_answer_enabled: Boolean = true,
    val ring_delay_seconds: Int = 8
)

@Serializable
data class CallTurn(
    val speaker: String, // "ai" | "caller"
    val text: String,
    val ts: Long,
    val audio_path: String? = null
)
