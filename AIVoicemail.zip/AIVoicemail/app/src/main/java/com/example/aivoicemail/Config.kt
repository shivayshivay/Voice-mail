package com.example.aivoicemail

/** Fill these in from your Supabase project: Project Settings > API. The anon/publishable key
 *  is safe to ship in the app -- access is controlled by Row Level Security (supabase.sql), not
 *  by keeping this secret. The OpenAI key is NOT here and must never be: see README. */
object Config {
    const val SUPABASE_URL = "https://prrnromjgxknoynemmrs.supabase.co"
    const val SUPABASE_ANON_KEY = "sb_publishable_T9LjW5oq-34Vw9IHW3DHmQ_q0dMth47"
}
