@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.aivoicemail

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

// ---------- Theme ----------

private val LightScheme = lightColorScheme(
    primary = Color(0xFF3454D1), onPrimary = Color.White,
    secondary = Color(0xFF5C7AEA), tertiary = Color(0xFFFF9F1C),
    primaryContainer = Color(0xFFE3E8FF), onPrimaryContainer = Color(0xFF14205B),
    background = Color(0xFFF2F4FC), surface = Color(0xFFFFFFFF)
)
private val DarkScheme = darkColorScheme(
    primary = Color(0xFF8FA6FF), onPrimary = Color(0xFF0B1442),
    secondary = Color(0xFF9DB2FF), tertiary = Color(0xFFFFC56B),
    primaryContainer = Color(0xFF26337A), onPrimaryContainer = Color(0xFFE3E8FF),
    background = Color(0xFF0E1020), surface = Color(0xFF171A2E)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Prefs.accountVerified(this)) WorkScheduler.schedulePeriodic(this)
        setContent { App() }
    }
}

private fun requiredPermissions(): Array<String> = buildList {
    add(Manifest.permission.READ_PHONE_STATE)
    add(Manifest.permission.ANSWER_PHONE_CALLS)
    add(Manifest.permission.RECORD_AUDIO)
    add(Manifest.permission.MODIFY_AUDIO_SETTINGS)
    add(Manifest.permission.READ_CALL_LOG)
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.toTypedArray()

private fun allGranted(c: Context) = requiredPermissions().all {
    ContextCompat.checkSelfPermission(c, it) == PackageManager.PERMISSION_GRANTED
}

private fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_LONG).show()

private fun formatTs(ms: Long): String =
    java.text.SimpleDateFormat("dd MMM, HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ms))

// ---------- Root ----------

@Composable
fun App() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val sp = ctx.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        val l = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> tick++ }
        sp.registerOnSharedPreferenceChangeListener(l)
        onDispose { sp.unregisterOnSharedPreferenceChangeListener(l) }
    }
    var dark by remember { mutableStateOf(Prefs.darkMode(ctx)) }

    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme) {
        Surface(Modifier.fillMaxSize()) {
            Shell(tick = tick, dark = dark, onToggleDark = {
                dark = !dark
                Prefs.setDarkMode(ctx, dark)
            })
        }
    }
}

/** Translucent, rounded-corner card -- the "glass-like" surface used throughout. True blur-
 *  behind glassmorphism needs a background to blur, which isn't practical behind a scrolling
 *  list; this gives the same visual language (soft transparency, light border, rounded corners)
 *  without relying on a blur effect that can't be verified without seeing it actually render. */
@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(scheme.surface.copy(alpha = 0.72f))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        content = content
    )
}

@Composable
fun SyncDot() {
    val ctx = LocalContext.current
    val status = Prefs.status(ctx, "ai")
    val color = when {
        status.contains("Error", true) || status.contains("failed", true) -> Color(0xFFD32F2F)
        status == "Not run yet" -> Color(0xFF9E9E9E)
        else -> Color(0xFF2E7D32)
    }
    Box(Modifier.size(10.dp).clip(CircleShape).background(color))
}

@Composable
fun Shell(tick: Int, dark: Boolean, onToggleDark: () -> Unit) {
    val ctx = LocalContext.current
    var selected by remember { mutableStateOf("setup") }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    fun go(v: String) { selected = v; scope.launch { drawerState.close() } }

    val titles = mapOf(
        "setup" to "Setup", "incoming" to "Incoming Calls", "outgoing" to "Outgoing Calls",
        "recorded" to "Recorded Calls", "conversations" to "Conversations"
    )

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text("AI Voicemail", Modifier.padding(16.dp), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                HorizontalDivider()
                titles.forEach { (key, label) ->
                    NavigationDrawerItem(
                        label = { Text(label) }, selected = selected == key,
                        onClick = { go(key) }, modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(titles[selected] ?: "AI Voicemail") },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu")
                        }
                    },
                    actions = {
                        SyncDot()
                        Spacer(Modifier.width(10.dp))
                        IconButton(onClick = onToggleDark) {
                            Text(if (dark) "\u2600\uFE0F" else "\uD83C\uDF19", fontSize = 18.sp)
                        }
                    }
                )
            }
        ) { padding ->
            Box(Modifier.padding(padding)) {
                when (selected) {
                    "incoming" -> CallListView(direction = "incoming", chatMode = false)
                    "outgoing" -> CallListView(direction = "outgoing", chatMode = false)
                    "recorded" -> CallListView(direction = "incoming", chatMode = false, aiHandledOnly = true)
                    "conversations" -> CallListView(direction = "incoming", chatMode = true, aiHandledOnly = true)
                    else -> SetupView(tick)
                }
            }
        }
    }
}

// ---------- Setup ----------

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    GlassCard {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        content()
    }
}

@Composable
fun SetupView(tick: Int) {
    Column(
        Modifier.fillMaxSize().safeDrawingPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        PermissionSection()
        AccountSection()
        AvailabilitySection()
        ContactsSection()
        PrivacyRulesSection()
        DiagnosticsSection()
        Text("Build: ${BuildConfig.BUILD_TIME}", fontSize = 10.sp, color = Color.Gray)
    }
}

@Composable
fun PermissionSection() {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(allGranted(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = allGranted(ctx)
    }
    Section("Permissions") {
        Text(if (granted) "All permissions granted \u2713" else "Phone, answer-call, microphone, call log and notification access are needed.", fontSize = 13.sp)
        if (!granted) Button(onClick = { launcher.launch(requiredPermissions()) }) { Text("Grant permissions") }
        OutlinedButton(onClick = {
            ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }) { Text("Open battery settings") }
        Text(
            "Set battery usage to Unrestricted, and check your phone's own autostart/background " +
                "app manager too (Vivo/OPPO/Xiaomi etc.) -- without both, incoming-call detection " +
                "can silently stop working while idle.",
            fontSize = 11.sp
        )
    }
}

@Composable
fun AccountSection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf(Prefs.accountEmail(ctx)) }
    var code by remember { mutableStateOf("") }
    var otpSent by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val verified = Prefs.accountVerified(ctx)
    val emailKb = KeyboardOptions(keyboardType = KeyboardType.Email)
    val numKb = KeyboardOptions(keyboardType = KeyboardType.Number)

    Section("Account" + if (verified) " \u2713" else "") {
        if (verified) {
            Text("Signed in as ${Prefs.accountEmail(ctx)}.", fontSize = 13.sp)
            TextButton(onClick = {
                scope.launch { SupabaseRepo.signOut() }
                Prefs.setAccountVerified(ctx, false); Prefs.setAccountEmail(ctx, "")
            }) { Text("Sign out") }
        } else {
            Text("Sign in with email to secure your call dashboard.", fontSize = 13.sp)
            OutlinedTextField(email, { email = it }, label = { Text("Email address") },
                keyboardOptions = emailKb, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(enabled = !busy, onClick = {
                if (!email.contains("@") || !email.contains(".")) { toast(ctx, "Enter a valid email"); return@Button }
                busy = true
                scope.launch {
                    try {
                        SupabaseRepo.sendEmailOtp(email.trim())
                        Prefs.setAccountEmail(ctx, email.trim())
                        otpSent = true
                        toast(ctx, "Code sent -- check your inbox")
                    } catch (e: Exception) { toast(ctx, "Error: ${e.message}") } finally { busy = false }
                }
            }) { Text(if (otpSent) "Resend code" else "Send code") }
            if (otpSent) {
                OutlinedTextField(code, { code = it }, label = { Text("6-digit code") },
                    keyboardOptions = numKb, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(enabled = !busy, onClick = {
                    val typed = code.filter { it.isDigit() }
                    if (typed.length < 6) { toast(ctx, "Enter the 6-digit code"); return@Button }
                    busy = true
                    scope.launch {
                        try {
                            SupabaseRepo.verifyEmailOtp(Prefs.accountEmail(ctx), typed)
                            Prefs.setAccountVerified(ctx, true)
                            WorkScheduler.schedulePeriodic(ctx)
                            WorkScheduler.runOnceNow(ctx)
                            toast(ctx, "Signed in")
                        } catch (e: Exception) { toast(ctx, "Error: ${e.message}") } finally { busy = false }
                    }
                }) { Text("Verify") }
            }
        }
    }
}

@Composable
fun AvailabilitySection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("available") }
    var customMessage by remember { mutableStateOf("") }
    var callbackWindow by remember { mutableStateOf("later today") }
    var autoAnswer by remember { mutableStateOf(true) }
    var ringDelay by remember { mutableStateOf("8") }
    var loaded by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(Prefs.accountVerified(ctx)) {
        if (!Prefs.accountVerified(ctx) || loaded) return@LaunchedEffect
        try {
            val s = HistoryRepo.fetchSettings()
            if (s != null) {
                status = s.status; customMessage = s.custom_message; callbackWindow = s.callback_window
                autoAnswer = s.auto_answer_enabled; ringDelay = s.ring_delay_seconds.toString()
            }
            loaded = true
        } catch (_: Exception) { }
    }

    if (!Prefs.accountVerified(ctx)) return

    Section("Availability & auto-answer") {
        Text("Status", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("available" to "Available", "busy" to "Busy", "in_meeting" to "In a meeting", "custom" to "Custom").forEach { (v, label) ->
                FilterChip(selected = status == v, onClick = { status = v }, label = { Text(label, fontSize = 11.sp) })
            }
        }
        if (status == "custom") {
            OutlinedTextField(customMessage, { customMessage = it }, label = { Text("Custom greeting") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        OutlinedTextField(callbackWindow, { callbackWindow = it }, label = { Text("Callback window (e.g. \"after 5pm\")") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Auto-answer calls", Modifier.weight(1f), fontSize = 13.sp)
            Switch(autoAnswer, { autoAnswer = it })
        }
        OutlinedTextField(ringDelay, { ringDelay = it.filter { d -> d.isDigit() }.take(2) }, label = { Text("Ring delay before auto-answer (seconds)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
        Button(enabled = !busy, onClick = {
            busy = true
            scope.launch {
                try {
                    val uid = SupabaseRepo.requireSignedIn()
                    val row = SettingsRow(
                        user_id = uid, status = status, custom_message = customMessage,
                        callback_window = callbackWindow, auto_answer_enabled = autoAnswer,
                        ring_delay_seconds = ringDelay.toIntOrNull() ?: 8
                    )
                    HistoryRepo.saveSettings(row)
                    LocalRules.refreshSettingsCache(ctx, row)
                    toast(ctx, "Saved")
                } catch (e: Exception) { toast(ctx, "Error: ${e.message}") } finally { busy = false }
            }
        }) { Text("Save availability") }
    }
}

@Composable
fun ContactsSection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var contacts by remember { mutableStateOf<List<ContactRow>>(emptyList()) }
    var number by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("vip") }
    var refreshKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(refreshKey, Prefs.accountVerified(ctx)) {
        if (!Prefs.accountVerified(ctx)) return@LaunchedEffect
        try {
            val list = HistoryRepo.fetchContacts()
            contacts = list
            LocalRules.refreshContactsCache(ctx, list)
        } catch (_: Exception) { }
    }

    if (!Prefs.accountVerified(ctx)) return

    Section("Priority contacts") {
        Text("VIPs ring through normally (AI never answers them). Blocked numbers never get AI engagement.", fontSize = 11.sp)
        contacts.forEach { contact ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text(contact.name.ifBlank { contact.number }, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text("${contact.number} -- ${contact.priority}", fontSize = 11.sp)
                }
                TextButton(onClick = {
                    scope.launch {
                        contact.id?.let { HistoryRepo.deleteContact(it) }
                        refreshKey++
                    }
                }) { Text("Remove") }
            }
        }
        HorizontalDivider()
        OutlinedTextField(number, { number = it }, label = { Text("Phone number") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(name, { name = it }, label = { Text("Name (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("vip" to "VIP", "normal" to "Normal", "blocked" to "Blocked").forEach { (v, label) ->
                FilterChip(selected = priority == v, onClick = { priority = v }, label = { Text(label, fontSize = 11.sp) })
            }
        }
        Button(onClick = {
            if (number.filter { it.isDigit() }.length < 7) { toast(ctx, "Enter a valid number"); return@Button }
            scope.launch {
                try {
                    HistoryRepo.upsertContact(ContactRow(number = number.trim(), name = name.trim(), priority = priority))
                    number = ""; name = ""
                    refreshKey++
                } catch (e: Exception) { toast(ctx, "Error: ${e.message}") }
            }
        }) { Text("Add contact") }
    }
}

@Composable
fun PrivacyRulesSection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var rules by remember { mutableStateOf<List<PrivacyRuleRow>>(emptyList()) }
    var phrase by remember { mutableStateOf("") }
    var refreshKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(refreshKey, Prefs.accountVerified(ctx)) {
        if (!Prefs.accountVerified(ctx)) return@LaunchedEffect
        try { rules = HistoryRepo.fetchPrivacyRules() } catch (_: Exception) { }
    }

    if (!Prefs.accountVerified(ctx)) return

    Section("Never disclose (privacy rules)") {
        Text(
            "Enforced in two layers: the AI is instructed never to mention these, AND every " +
                "reply is checked in code and blocked if it contains any of them -- the code " +
                "check is what actually guarantees it, not just the instruction.",
            fontSize = 11.sp
        )
        rules.forEach { rule ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(rule.phrase, fontSize = 13.sp)
                TextButton(onClick = {
                    scope.launch { rule.id?.let { HistoryRepo.deletePrivacyRule(it) }; refreshKey++ }
                }) { Text("Remove") }
            }
        }
        HorizontalDivider()
        OutlinedTextField(phrase, { phrase = it }, label = { Text("e.g. \"home address\", \"salary\"") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            if (phrase.isBlank()) return@Button
            scope.launch {
                try { HistoryRepo.addPrivacyRule(phrase.trim()); phrase = ""; refreshKey++ }
                catch (e: Exception) { toast(ctx, "Error: ${e.message}") }
            }
        }) { Text("Add rule") }
    }
}

@Composable
fun DiagnosticsSection() {
    val ctx = LocalContext.current
    Section("Diagnostics") {
        listOf("call" to "Answering", "recording" to "Recording", "ai" to "AI processing", "hangup" to "Hang-up", "upload" to "Upload").forEach { (key, label) ->
            Text("$label: ${Prefs.status(ctx, key)}", fontSize = 12.sp)
        }
    }
}

// ---------- Call list / conversations ----------

@Composable
fun CallListView(direction: String, chatMode: Boolean, aiHandledOnly: Boolean = false) {
    val ctx = LocalContext.current
    var items by remember { mutableStateOf<List<CallRow>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var refreshKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(refreshKey, direction) {
        if (!Prefs.accountVerified(ctx)) return@LaunchedEffect
        error = null
        try {
            var list = HistoryRepo.fetchCalls(direction)
            if (aiHandledOnly) list = list.filter { !it.turns.isNullOrBlank() }
            items = list
        } catch (e: Exception) { error = e.message ?: e::class.simpleName }
    }

    val filtered = items?.filter {
        query.isBlank() ||
            it.number.contains(query, true) ||
            (it.summary ?: "").contains(query, true) ||
            (it.transcript ?: "").contains(query, true)
    }

    Column(
        Modifier.fillMaxSize().safeDrawingPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (!Prefs.accountVerified(ctx)) {
            Text("Sign in under Setup to see your calls.", fontSize = 13.sp)
            return@Column
        }
        OutlinedTextField(
            query, { query = it },
            placeholder = { Text("Search number, summary, transcript...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        TextButton(onClick = { refreshKey++ }) { Text("Refresh") }
        when {
            error != null -> Text("Error: $error", color = Color(0xFFD32F2F), fontSize = 13.sp)
            items == null -> Text("Loading...", fontSize = 13.sp)
            filtered.isNullOrEmpty() -> Text("No calls here yet.", fontSize = 13.sp)
            else -> filtered.forEach { row -> if (chatMode) ConversationCard(row) else CallCard(row) }
        }
    }
}

@Composable
fun CallCard(row: CallRow) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var expanded by remember { mutableStateOf(false) }

    GlassCard(Modifier.clickable { expanded = !expanded }) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(row.number, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            if (row.urgent == true) Text("URGENT", color = Color(0xFFD32F2F), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Text("${formatTs(row.started_at)} -- ${row.duration_seconds}s -- ${row.status}" + (row.priority?.let { " -- $it" } ?: ""), fontSize = 12.sp)
        if (!row.summary.isNullOrBlank()) Text(row.summary, fontSize = 13.sp)
        if (expanded) {
            if (!row.transcript.isNullOrBlank()) {
                Text("Transcript", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Text(row.transcript, fontSize = 12.sp)
            }
            if (!row.extracted.isNullOrBlank()) {
                Text("Extracted info", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Text(row.extracted, fontSize = 12.sp)
            }
            if (!row.recording_path.isNullOrBlank()) {
                OutlinedButton(onClick = {
                    scope.launch {
                        try {
                            val url = HistoryRepo.recordingUrl(row.recording_path)
                            ctx.startActivity(Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(Uri.parse(url), "audio/*")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            })
                        } catch (e: Exception) { toast(ctx, "Couldn't open recording: ${e.message}") }
                    }
                }) { Text("Play recording") }
            }
        }
    }
}

@Composable
fun ConversationCard(row: CallRow) {
    val turns = remember(row.turns) {
        try {
            if (row.turns.isNullOrBlank()) emptyList()
            else Json { ignoreUnknownKeys = true }.decodeFromString<List<CallTurn>>(row.turns)
        } catch (_: Exception) { emptyList() }
    }
    GlassCard {
        Text("${row.number} -- ${formatTs(row.started_at)}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        if (turns.isEmpty()) {
            Text("No conversation turns recorded for this call.", fontSize = 12.sp)
        } else {
            turns.forEach { turn ->
                val isAi = turn.speaker == "ai"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isAi) Arrangement.Start else Arrangement.End) {
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (isAi) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.secondary.copy(alpha = 0.25f)
                            )
                            .padding(10.dp)
                            .widthIn(max = 260.dp)
                    ) {
                        Column {
                            Text(if (isAi) "AI" else "Caller", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(turn.text, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}
