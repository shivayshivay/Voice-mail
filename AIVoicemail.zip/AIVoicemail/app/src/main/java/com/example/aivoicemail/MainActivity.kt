@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.aivoicemail

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

private val AppColorScheme = lightColorScheme(
    primary = Color(0xFF3454D1),
    onPrimary = Color.White,
    secondary = Color(0xFF5C7AEA),
    tertiary = Color(0xFFFF9F1C),
    primaryContainer = Color(0xFFE3E8FF),
    onPrimaryContainer = Color(0xFF14205B)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = AppColorScheme) { Surface(Modifier.fillMaxSize()) { App() } }
        }
    }
}

private fun requiredPermissions(): Array<String> = buildList {
    add(Manifest.permission.READ_PHONE_STATE)
    add(Manifest.permission.ANSWER_PHONE_CALLS)
    add(Manifest.permission.RECORD_AUDIO)
    add(Manifest.permission.MODIFY_AUDIO_SETTINGS)
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.toTypedArray()

private fun allGranted(c: Context) = requiredPermissions().all {
    ContextCompat.checkSelfPermission(c, it) == PackageManager.PERMISSION_GRANTED
}

private fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_LONG).show()

private fun formatTs(ms: Long): String =
    java.text.SimpleDateFormat("dd MMM, HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ms))

@Composable
fun App() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val sp = ctx.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        val l = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> tick++ }
        sp.registerOnSharedPreferenceChangeListener(l)
        onDispose { sp.unregisterOnSharedPreferenceChangeListener(l) }
    }
    Column(
        Modifier.fillMaxSize().safeDrawingPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("AI Voicemail", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        PermissionSection()
        AccountSection()
        HowItWorksSection()
        DiagnosticsSection()
        CallHistorySection(tick)
        Text("Build: ${BuildConfig.BUILD_TIME}", fontSize = 10.sp, color = Color.Gray)
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            content()
        }
    }
}

@Composable
fun PermissionSection() {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(allGranted(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = allGranted(ctx)
    }
    Section("Permissions") {
        Text(if (granted) "All permissions granted ✓" else "Phone, answer-call, microphone and notification access are needed.", fontSize = 13.sp)
        if (!granted) Button(onClick = { launcher.launch(requiredPermissions()) }) { Text("Grant permissions") }
        OutlinedButton(onClick = {
            ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }) { Text("Open battery settings") }
        Text(
            "Set battery usage to Unrestricted, and check your phone's own autostart/background " +
                "app manager too (Settings > Battery, or Vivo/OPPO/Xiaomi's own app manager) -- " +
                "without both, incoming-call detection can silently stop working while idle.",
            fontSize = 11.sp
        )
    }
}

@Composable
fun AccountSection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf(Prefs.accountEmail(ctx)) }
    var code by remember { mutableStateOf("") }
    var otpSent by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val verified = Prefs.accountVerified(ctx)
    val emailKb = KeyboardOptions(keyboardType = KeyboardType.Email)
    val numKb = KeyboardOptions(keyboardType = KeyboardType.Number)

    Section("Account" + if (verified) " ✓" else "") {
        if (verified) {
            Text("Signed in as ${Prefs.accountEmail(ctx)}.", fontSize = 13.sp)
            TextButton(onClick = {
                scope.launch { SupabaseRepo.signOut() }
                Prefs.setAccountVerified(ctx, false); Prefs.setAccountEmail(ctx, "")
            }) { Text("Sign out") }
        } else {
            Text("Sign in with email to secure your call dashboard.", fontSize = 13.sp)
            OutlinedTextField(email, { email = it }, label = { Text("Email address") },
                keyboardOptions = emailKb, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(enabled = !busy, onClick = {
                if (!email.contains("@") || !email.contains(".")) { toast(ctx, "Enter a valid email"); return@Button }
                busy = true
                scope.launch {
                    try {
                        SupabaseRepo.sendEmailOtp(email.trim())
                        Prefs.setAccountEmail(ctx, email.trim())
                        otpSent = true
                        toast(ctx, "Code sent -- check your inbox")
                    } catch (e: Exception) { toast(ctx, "Error: ${e.message}") } finally { busy = false }
                }
            }) { Text(if (otpSent) "Resend code" else "Send code") }
            if (otpSent) {
                OutlinedTextField(code, { code = it }, label = { Text("6-digit code") },
                    keyboardOptions = numKb, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(enabled = !busy, onClick = {
                    val typed = code.filter { it.isDigit() }
                    if (typed.length < 6) { toast(ctx, "Enter the 6-digit code"); return@Button }
                    busy = true
                    scope.launch {
                        try {
                            SupabaseRepo.verifyEmailOtp(Prefs.accountEmail(ctx), typed)
                            Prefs.setAccountVerified(ctx, true)
                            toast(ctx, "Signed in")
                        } catch (e: Exception) { toast(ctx, "Error: ${e.message}") } finally { busy = false }
                    }
                }) { Text("Verify") }
            }
        }
    }
}

@Composable
fun HowItWorksSection() {
    Section("How it works") {
        Text(
            "When a call rings, you'll get a notification with a \"Let AI Answer\" action. Tap it " +
                "and the AI answers, plays a short greeting, and records the conversation through the " +
                "speaker/mic (not a clean call-audio feed -- see README for why). After the call ends, " +
                "the recording uploads and is transcribed + summarized automatically; it'll show up " +
                "below once that finishes.",
            fontSize = 12.sp
        )
    }
}

@Composable
fun DiagnosticsSection() {
    val ctx = LocalContext.current
    Section("Diagnostics") {
        listOf("call" to "Answering", "recording" to "Recording", "upload" to "Upload", "ai" to "AI processing", "hangup" to "Hang-up").forEach { (key, label) ->
            Text("$label: ${Prefs.status(ctx, key)}", fontSize = 12.sp)
        }
    }
}

@Composable
fun CallHistorySection(tick: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<CallRow>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var refreshKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(refreshKey) {
        if (!Prefs.accountVerified(ctx)) return@LaunchedEffect
        error = null
        try { items = HistoryRepo.fetchCalls() } catch (e: Exception) { error = e.message ?: e::class.simpleName }
    }

    Section("Call history") {
        TextButton(onClick = { refreshKey++ }) { Text("Refresh") }
        when {
            !Prefs.accountVerified(ctx) -> Text("Sign in above to see your calls.", fontSize = 13.sp)
            error != null -> Text("Error: $error", color = Color(0xFFD32F2F), fontSize = 13.sp)
            items == null -> Text("Loading...", fontSize = 13.sp)
            items!!.isEmpty() -> Text("No calls yet.", fontSize = 13.sp)
            else -> items!!.forEach { row -> CallCard(row) }
        }
    }
}

@Composable
fun CallCard(row: CallRow) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var expanded by remember { mutableStateOf(false) }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp).fillMaxWidth().clickable { expanded = !expanded }, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(row.number, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                if (row.urgent == true) Text("URGENT", color = Color(0xFFD32F2F), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Text("${formatTs(row.started_at)} -- ${row.duration_seconds}s -- ${row.status}", fontSize = 12.sp)
            if (!row.summary.isNullOrBlank()) Text(row.summary, fontSize = 13.sp)
            if (expanded) {
                if (!row.transcript.isNullOrBlank()) {
                    Text("Transcript", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Text(row.transcript, fontSize = 12.sp)
                }
                if (!row.extracted.isNullOrBlank()) {
                    Text("Extracted info", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Text(row.extracted, fontSize = 12.sp)
                }
                if (!row.recording_path.isNullOrBlank()) {
                    OutlinedButton(onClick = {
                        scope.launch {
                            try {
                                val url = HistoryRepo.recordingUrl(row.recording_path)
                                val intent = Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(Uri.parse(url), "audio/*")
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                ctx.startActivity(intent)
                            } catch (e: Exception) { toast(ctx, "Couldn't open recording: ${e.message}") }
                        }
                    }) { Text("Play recording") }
                }
            }
        }
    }
}

