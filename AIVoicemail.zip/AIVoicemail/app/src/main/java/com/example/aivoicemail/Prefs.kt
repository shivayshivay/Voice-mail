package com.example.aivoicemail

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prefs {
    const val NAME = "aivm_prefs"
    private fun sp(c: Context) = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)
    private fun gs(c: Context, k: String, d: String = "") = sp(c).getString(k, d) ?: d
    private fun ps(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
    private fun gb(c: Context, k: String, d: Boolean = false) = sp(c).getBoolean(k, d)
    private fun pb(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()

    fun accountEmail(c: Context) = gs(c, "account_email")
    fun setAccountEmail(c: Context, v: String) = ps(c, "account_email", v)
    fun accountVerified(c: Context) = gb(c, "account_verified")
    fun setAccountVerified(c: Context, v: Boolean) = pb(c, "account_verified", v)

    // The call currently ringing / being AI-handled, so the service (started from a
    // notification tap, a different code path than the receiver) knows which number it's on.
    fun ringingNumber(c: Context) = gs(c, "ringing_number")
    fun setRingingNumber(c: Context, v: String) = ps(c, "ringing_number", v)
    fun callState(c: Context) = gs(c, "call_state", "IDLE")
    fun setCallState(c: Context, v: String) = ps(c, "call_state", v)
    fun activeCallId(c: Context) = gs(c, "active_call_id")
    fun setActiveCallId(c: Context, v: String) = ps(c, "active_call_id", v)

    fun setStatus(c: Context, key: String, text: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        ps(c, "status_$key", "$time -- $text")
    }
    fun status(c: Context, key: String) = gs(c, "status_$key", "Not run yet")

    fun resetAll(c: Context) = sp(c).edit().clear().apply()
}
