package com.example.aivoicemail

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!Prefs.accountVerified(c)) return
        MonitoringService.start(c)
        WorkScheduler.schedulePeriodic(c)
        WorkScheduler.runOnceNow(c)
    }
}
