// Supabase Edge Function: process-call
//
// Runs once, after a call fully ends. Unlike V1, it no longer transcribes a monolithic
// recording -- each turn was already transcribed live by respond-to-turn, so `calls.turns`
// already holds the full conversation text. This function's job is just the wrap-up: an
// overall summary, an urgent flag, and extracted names/dates/phone numbers/suggested callback.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY")!;

interface CallTurn {
  speaker: "ai" | "caller";
  text: string;
  ts: number;
}

Deno.serve(async (req: Request) => {
  try {
    const { call_id } = await req.json();
    if (!call_id) {
      return new Response(JSON.stringify({ error: "call_id required" }), { status: 400 });
    }

    const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);
    const { data: call, error: fetchErr } = await admin.from("calls").select("*").eq("id", call_id).single();
    if (fetchErr || !call) {
      return new Response(JSON.stringify({ error: "call not found" }), { status: 404 });
    }

    const turns: CallTurn[] = call.turns ? JSON.parse(call.turns) : [];
    const transcript = turns.map((t) => `${t.speaker}: ${t.text}`).join("\n");

    if (!transcript.trim()) {
      await admin.from("calls").update({ status: "done", transcript: "", summary: "No conversation was recorded for this call." }).eq("id", call_id);
      return new Response(JSON.stringify({ ok: true, note: "empty transcript" }));
    }

    const prompt = `Here is the full transcript of a phone call handled by an AI voicemail assistant:
"""
${transcript}
"""
Respond ONLY with JSON matching exactly this shape, no other text:
{
  "summary": "one or two sentence summary of the call",
  "urgent": true or false,
  "names": ["any person names mentioned"],
  "dates": ["any dates or times mentioned"],
  "phone_numbers": ["any phone numbers mentioned"],
  "suggested_callback": "a short suggested reply or action, or empty string if none applies"
}`;

    const chatRes = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      }),
    });
    if (!chatRes.ok) {
      const errText = await chatRes.text();
      await admin.from("calls").update({ status: "failed", transcript }).eq("id", call_id);
      return new Response(JSON.stringify({ error: "summary generation failed", detail: errText }), { status: 500 });
    }
    const chatJson = await chatRes.json();
    const content: string = chatJson.choices?.[0]?.message?.content ?? "{}";
    let parsed: Record<string, unknown> = {};
    try { parsed = JSON.parse(content); } catch (_e) { parsed = {}; }

    const summary = (parsed.summary as string) ?? "";
    const urgent = parsed.urgent === true;
    const extracted = JSON.stringify({
      names: parsed.names ?? [],
      dates: parsed.dates ?? [],
      phone_numbers: parsed.phone_numbers ?? [],
      suggested_callback: parsed.suggested_callback ?? "",
    });

    await admin.from("calls").update({
      status: "done",
      transcript,
      summary,
      urgent,
      extracted,
    }).eq("id", call_id);

    return new Response(JSON.stringify({ ok: true }), { headers: { "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500 });
  }
});
