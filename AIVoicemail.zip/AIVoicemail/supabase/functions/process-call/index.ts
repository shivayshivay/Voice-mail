// Supabase Edge Function: process-call
// Runs server-side only. Holds the OpenAI key (set once via Supabase dashboard > Edge
// Functions > Secrets -- never put it in the Android app or in GitHub). Triggered by the app
// right after a recording uploads; downloads the audio, transcribes it with Whisper, asks GPT
// for a summary + extracted details, and writes the results back to the `calls` row.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY")!;

Deno.serve(async (req: Request) => {
  try {
    const { call_id } = await req.json();
    if (!call_id) {
      return new Response(JSON.stringify({ error: "call_id required" }), { status: 400 });
    }

    const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

    const { data: call, error: fetchErr } = await admin
      .from("calls")
      .select("*")
      .eq("id", call_id)
      .single();
    if (fetchErr || !call) {
      return new Response(JSON.stringify({ error: "call not found" }), { status: 404 });
    }
    if (!call.recording_path) {
      return new Response(JSON.stringify({ error: "no recording_path on this call" }), { status: 400 });
    }

    const { data: fileData, error: dlErr } = await admin
      .storage
      .from("call_recordings")
      .download(call.recording_path);
    if (dlErr || !fileData) {
      await admin.from("calls").update({ status: "failed" }).eq("id", call_id);
      return new Response(JSON.stringify({ error: "could not download recording", detail: dlErr?.message }), { status: 500 });
    }

    // 1. Transcribe with Whisper.
    const form = new FormData();
    form.append("file", fileData, "recording.m4a");
    form.append("model", "whisper-1");
    const whisperRes = await fetch("https://api.openai.com/v1/audio/transcriptions", {
      method: "POST",
      headers: { Authorization: `Bearer ${OPENAI_API_KEY}` },
      body: form,
    });
    if (!whisperRes.ok) {
      const errText = await whisperRes.text();
      await admin.from("calls").update({ status: "failed" }).eq("id", call_id);
      return new Response(JSON.stringify({ error: "whisper transcription failed", detail: errText }), { status: 500 });
    }
    const whisperJson = await whisperRes.json();
    const transcript: string = whisperJson.text ?? "";

    // 2. Summarize + extract structured info with GPT.
    const prompt = `You are processing a phone call transcript recorded by an AI voicemail assistant.
Transcript:
"""
${transcript}
"""
Respond ONLY with JSON matching exactly this shape, no other text:
{
  "summary": "one or two sentence summary of the call",
  "urgent": true or false,
  "names": ["any person names mentioned"],
  "dates": ["any dates or times mentioned"],
  "phone_numbers": ["any phone numbers mentioned"],
  "suggested_callback": "a short suggested reply or action, or empty string if none applies"
}`;

    const chatRes = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      }),
    });
    if (!chatRes.ok) {
      const errText = await chatRes.text();
      await admin.from("calls").update({ status: "failed", transcript }).eq("id", call_id);
      return new Response(JSON.stringify({ error: "summary generation failed", detail: errText }), { status: 500 });
    }
    const chatJson = await chatRes.json();
    const content: string = chatJson.choices?.[0]?.message?.content ?? "{}";
    let parsed: Record<string, unknown> = {};
    try { parsed = JSON.parse(content); } catch (_e) { parsed = {}; }

    const summary = (parsed.summary as string) ?? "";
    const urgent = parsed.urgent === true;
    const extracted = JSON.stringify({
      names: parsed.names ?? [],
      dates: parsed.dates ?? [],
      phone_numbers: parsed.phone_numbers ?? [],
      suggested_callback: parsed.suggested_callback ?? "",
    });

    await admin.from("calls").update({
      status: "done",
      transcript,
      summary,
      urgent,
      extracted,
    }).eq("id", call_id);

    return new Response(JSON.stringify({ ok: true }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500 });
  }
});
