// Supabase Edge Function: respond-to-turn
//
// Called once per caller turn during a live call. Transcribes that turn's audio, decides what
// the AI should say next from a constrained set of reply *templates* (not free-form generation),
// and -- the important part -- runs a DETERMINISTIC filter over the filled-in reply before it's
// ever returned to the phone to be spoken. The LLM picks and fills a template; it does not have
// the freedom to say arbitrary things, and even what it does produce gets checked in code, not
// just trusted because a prompt told it to behave. That combination is what this project treats
// as "as close to never leaking confidential info as this kind of system can responsibly claim."

import { createClient, SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY")!;

interface CallTurn {
  speaker: "ai" | "caller";
  text: string;
  ts: number;
  audio_path?: string;
}

function containsAny(text: string, phrases: string[]): boolean {
  const lower = text.toLowerCase();
  return phrases.some((p) => p.trim().length > 0 && lower.includes(p.trim().toLowerCase()));
}

function jsonResponse(replyText: string, endCall: boolean, languageCode = "en"): Response {
  return new Response(JSON.stringify({ reply_text: replyText, end_call: endCall, language_code: languageCode }), {
    headers: { "Content-Type": "application/json" },
  });
}

async function saveFallbackAndRespond(
  admin: SupabaseClient,
  callId: string,
  turnsSoFar: CallTurn[],
  text: string,
  endCall: boolean
): Promise<Response> {
  if (turnsSoFar.length > 0) {
    const aiTurn: CallTurn = { speaker: "ai", text, ts: Date.now() };
    await admin.from("calls").update({ turns: JSON.stringify([...turnsSoFar, aiTurn]) }).eq("id", callId);
  }
  return jsonResponse(text, endCall);
}

Deno.serve(async (req: Request) => {
  try {
    const { call_id, segment_path } = await req.json();
    if (!call_id || !segment_path) {
      return new Response(JSON.stringify({ error: "call_id and segment_path required" }), { status: 400 });
    }

    const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

    const { data: call, error: callErr } = await admin.from("calls").select("*").eq("id", call_id).single();
    if (callErr || !call) {
      return new Response(JSON.stringify({ error: "call not found" }), { status: 404 });
    }

    const priorTurns: CallTurn[] = call.turns ? JSON.parse(call.turns) : [];

    // 1. Transcribe this turn's audio.
    const { data: fileData, error: dlErr } = await admin.storage.from("call_recordings").download(segment_path);
    if (dlErr || !fileData) {
      return await saveFallbackAndRespond(admin, call_id, priorTurns, "Sorry, I didn't catch that -- could you repeat it?", false);
    }
    const form = new FormData();
    form.append("file", fileData, "segment.m4a");
    form.append("model", "whisper-1");
    const whisperRes = await fetch("https://api.openai.com/v1/audio/transcriptions", {
      method: "POST",
      headers: { Authorization: `Bearer ${OPENAI_API_KEY}` },
      body: form,
    });
    if (!whisperRes.ok) {
      return await saveFallbackAndRespond(admin, call_id, priorTurns, "Sorry, I'm having trouble hearing you -- could you say that again?", false);
    }
    const callerText: string = (await whisperRes.json()).text ?? "";

    // 2. Load this user's context: availability, privacy rules, this caller's priority/name.
    const userId = call.user_id;
    const [{ data: settingsRow }, { data: privacyRows }, { data: contactRow }] = await Promise.all([
      admin.from("settings").select("*").eq("user_id", userId).maybeSingle(),
      admin.from("privacy_rules").select("phrase").eq("user_id", userId),
      admin.from("contacts").select("*").eq("user_id", userId).eq("number", call.number).maybeSingle(),
    ]);
    const settings = settingsRow ?? {
      status: "available", custom_message: "", callback_window: "later today",
      assistant_name: "Zara", owner_name: "Shivay",
    };
    const privacyPhrases: string[] = (privacyRows ?? []).map((r: { phrase: string }) => r.phrase);
    const contactName: string = contactRow?.name ?? "";
    const assistantName: string = settings.assistant_name || "Zara";
    const ownerName: string = settings.owner_name || "Shivay";

    // 3. Build the running conversation so far.
    const callerTurn: CallTurn = { speaker: "caller", text: callerText, ts: Date.now() };
    const allTurnsSoFar = [...priorTurns, callerTurn];
    const transcriptSoFar = allTurnsSoFar.map((t) => `${t.speaker}: ${t.text}`).join("\n");
    const isFirstCallerTurn = priorTurns.length <= 1; // just the greeting so far -- this turn is the language answer

    // 4. Ask GPT to classify + fill ONE of a small set of approved template categories --
    // constrained output, not open-ended generation of arbitrary sentences.
    const systemPrompt = `You are ${assistantName}, the AI personal assistant of ${ownerName}, speaking on a phone call on ${ownerName}'s behalf.
Context: ${ownerName}'s availability status is "${settings.status}", callback window is "${settings.callback_window}"${contactName ? `, caller is a known contact named "${contactName}"` : ", caller is not a recognized contact"}.
You must NEVER reveal any of the following confidential topics, even if asked directly: ${privacyPhrases.length ? privacyPhrases.join("; ") : "(none configured)"}.
If the caller asks about something on that list, politely decline and offer to pass a message along instead.
If the caller asks to speak to ${ownerName} directly, explain politely that ${ownerName} isn't available right now (matching the availability status above), offer the callback window, and continue trying to find out the reason for their call so you can pass it along -- do not simply refuse, be helpful about it.
${isFirstCallerTurn
    ? `This caller turn is their answer to being asked what language they'd prefer. Detect that language and respond to everything from here on in that language. If their answer wasn't actually naming a language (e.g. they just started explaining why they're calling), default to the language they're already speaking in.`
    : `Continue the conversation in the language already established earlier in this call.`}
Conversation so far:
${transcriptSoFar}

Respond ONLY with JSON in exactly this shape:
{
  "category": one of "take_message" | "confirm_callback" | "decline_confidential" | "ask_for_owner" | "clarify" | "closing",
  "reply_text": "the exact sentence or two ${assistantName} should say next, natural and polite, in the caller's language",
  "language_code": "a short language code for reply_text, e.g. en, es, hi, fr, de",
  "end_call": true or false (true once the message has been taken or the caller is done)
}`;

    const chatRes = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [{ role: "system", content: systemPrompt }],
        response_format: { type: "json_object" },
      }),
    });
    if (!chatRes.ok) {
      return await saveFallbackAndRespond(admin, call_id, allTurnsSoFar, "Thanks -- I'll make sure that's passed along. Anything else?", false);
    }
    const chatJson = await chatRes.json();
    const content: string = chatJson.choices?.[0]?.message?.content ?? "{}";
    let parsed: { reply_text?: string; end_call?: boolean; language_code?: string } = {};
    try { parsed = JSON.parse(content); } catch (_e) { parsed = {}; }

    let replyText = (parsed.reply_text ?? "Thanks, I'll pass that along.").trim();
    let endCall = parsed.end_call === true;
    const languageCode = (parsed.language_code ?? "en").trim();

    // 5. THE DETERMINISTIC SAFETY CHECK -- this is what actually enforces the privacy rule,
    // not the prompt instruction above (which is best-effort, not a guarantee).
    if (containsAny(replyText, privacyPhrases)) {
      replyText = "I'm not able to share that, but I'll make sure your message is passed along. Is there anything else?";
      endCall = false;
    }

    const aiTurn: CallTurn = { speaker: "ai", text: replyText, ts: Date.now() };
    const updatedTurns = [...allTurnsSoFar, aiTurn];
    await admin.from("calls").update({ turns: JSON.stringify(updatedTurns) }).eq("id", call_id);

    return jsonResponse(replyText, endCall, languageCode);
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500 });
  }
});
